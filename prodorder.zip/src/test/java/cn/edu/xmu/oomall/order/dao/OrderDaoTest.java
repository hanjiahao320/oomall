package cn.edu.xmu.oomall.order.dao;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class OrderDaoTest {

    @Test
    void getOrderById() {
    }

    @Test
    void searchOrders() {
    }

    @Test
    void updateOrder() {
    }

    @Test
    void updateOrderStatus() {
    }
}