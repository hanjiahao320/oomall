package cn.edu.xmu.oomall.order.controller.vo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

class OrderVoTest {

    private OrderVo orderVoUnderTest;

    @BeforeEach
    void setUp() {
        orderVoUnderTest = new OrderVo();
    }

    @Test
    void testSetOrderItems() {
        orderVoUnderTest.setOrderItems(List.of(new OrderItemVo()));
    }
}
