package cn.edu.xmu.oomall.order.controller;

import cn.edu.xmu.javaee.core.exception.BusinessException;
import cn.edu.xmu.oomall.order.controller.vo.OrderItemVo;
import cn.edu.xmu.oomall.order.controller.vo.OrderVo;
import cn.edu.xmu.oomall.order.service.OrderService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Collections;
import java.util.List;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(OrderController.class)
class OrderControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private OrderService mockOrderService;

    @Test
    void testGetOrderById() throws Exception {
        // Setup
        // Configure OrderService.getOrderById(...).
        final OrderVo orderVo = new OrderVo();
        final OrderItemVo orderItemVo = new OrderItemVo();
        orderItemVo.setOnsaleId(0L);
        orderItemVo.setQuantity(0);
        orderItemVo.setActId(0L);
        orderItemVo.setCouponId(0L);
        orderVo.setItems(List.of(orderItemVo));
        when(mockOrderService.getOrderById(0L, 0L)).thenReturn(orderVo);

        // Run the test and verify the results
        mockMvc.perform(get("/orders/{orderId}", 0)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().json("{}", true));
    }

    @Test
    void testGetOrderById_OrderServiceThrowsBusinessException() throws Exception {
        // Setup
        when(mockOrderService.getOrderById(0L, 0L)).thenThrow(BusinessException.class);

        // Run the test and verify the results
        mockMvc.perform(get("/orders/{orderId}", 0)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().json("{}", true));
    }

    @Test
    void testPayOrder() throws Exception {
        // Setup
        // Run the test and verify the results
        mockMvc.perform(post("/orders/{orderId}/pay", 0)
                        .content("content").contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().json("{}", true));
        verify(mockOrderService).payOrder(0L, 0L);
    }

    @Test
    void testPayOrder_OrderServiceThrowsBusinessException() throws Exception {
        // Setup
        doThrow(BusinessException.class).when(mockOrderService).payOrder(0L, 0L);

        // Run the test and verify the results
        mockMvc.perform(post("/orders/{orderId}/pay", 0)
                        .content("content").contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().json("{}", true));
    }

    @Test
    void testCancelOrder() throws Exception {
        // Setup
        // Run the test and verify the results
        mockMvc.perform(post("/orders/{orderId}/cancel", 0)
                        .content("content").contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().json("{}", true));
        verify(mockOrderService).cancelOrder(0L, 0L);
    }

    @Test
    void testCancelOrder_OrderServiceThrowsBusinessException() throws Exception {
        // Setup
        doThrow(BusinessException.class).when(mockOrderService).cancelOrder(0L, 0L);

        // Run the test and verify the results
        mockMvc.perform(post("/orders/{orderId}/cancel", 0)
                        .content("content").contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().json("{}", true));
    }

    @Test
    void testSearchOrders() throws Exception {
        // Setup
        // Configure OrderService.searchOrders(...).
        final OrderVo orderVo = new OrderVo();
        final OrderItemVo orderItemVo = new OrderItemVo();
        orderItemVo.setOnsaleId(0L);
        orderItemVo.setQuantity(0);
        orderItemVo.setActId(0L);
        orderItemVo.setCouponId(0L);
        orderVo.setItems(List.of(orderItemVo));
        final List<OrderVo> orderVos = List.of(orderVo);
        when(mockOrderService.searchOrders("itemName", 0L, 0, 0)).thenReturn(orderVos);

        // Run the test and verify the results
        mockMvc.perform(get("/orders")
                        .param("itemName", "itemName")
                        .param("customerId", "0")
                        .param("page", "0")
                        .param("size", "0")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().json("{}", true));
    }

    @Test
    void testSearchOrders_OrderServiceReturnsNoItems() throws Exception {
        // Setup
        when(mockOrderService.searchOrders("itemName", 0L, 0, 0)).thenReturn(Collections.emptyList());

        // Run the test and verify the results
        mockMvc.perform(get("/orders")
                        .param("itemName", "itemName")
                        .param("customerId", "0")
                        .param("page", "0")
                        .param("size", "0")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().json("[]", true));
    }

    @Test
    void testSearchOrders_OrderServiceThrowsBusinessException() throws Exception {
        // Setup
        when(mockOrderService.searchOrders("itemName", 0L, 0, 0)).thenThrow(BusinessException.class);

        // Run the test and verify the results
        mockMvc.perform(get("/orders")
                        .param("itemName", "itemName")
                        .param("customerId", "0")
                        .param("page", "0")
                        .param("size", "0")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().json("{}", true));
    }
}
