package cn.edu.xmu.oomall.order.controller.dto;

import org.junit.jupiter.api.BeforeEach;

class OrderDtoTest {

    private OrderDto orderDtoUnderTest;

    @BeforeEach
    void setUp() {
        orderDtoUnderTest = new OrderDto();
    }
}
