package cn.edu.xmu.oomall.order.dao.bo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

class OrderItemBoTest {

    private OrderItemBo orderItemBoUnderTest;

    @BeforeEach
    void setUp() {
        orderItemBoUnderTest = new OrderItemBo(0L, 0L, "creatorName", 0L, "modifierName",
                LocalDateTime.of(2020, 1, 1, 0, 0, 0), 0, LocalDateTime.of(2020, 1, 1, 0, 0, 0), 0L, 0L, 0L, 0, 0L, 0L,
                0L, "name", 0L, 0L, (byte) 0b0, 0L);
    }

    @Test
    void testSetGmtCreate() {
        orderItemBoUnderTest.setGmtCreate(LocalDateTime.of(2020, 1, 1, 0, 0, 0));
    }

    @Test
    void testSetGmtModified() {
        orderItemBoUnderTest.setGmtModified(LocalDateTime.of(2020, 1, 1, 0, 0, 0));
    }
}
