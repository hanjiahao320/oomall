package cn.edu.xmu.oomall.order.service.po;

import org.junit.jupiter.api.BeforeEach;

class OrderItemPoTest {

    private OrderItemPo orderItemPoUnderTest;

    @BeforeEach
    void setUp() {
        orderItemPoUnderTest = new OrderItemPo();
    }
}
