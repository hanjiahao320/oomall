package cn.edu.xmu.oomall.order.controller.vo;

import org.junit.jupiter.api.BeforeEach;

class OrderItemVoTest {

    private OrderItemVo orderItemVoUnderTest;

    @BeforeEach
    void setUp() {
        orderItemVoUnderTest = new OrderItemVo();
    }
}
