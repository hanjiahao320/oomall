package cn.edu.xmu.oomall.order.service.po;

import cn.edu.xmu.oomall.order.dao.bo.OrderStatus;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class OrderPoTest {

    private OrderPo orderPoUnderTest;

    @BeforeEach
    void setUp() {
        orderPoUnderTest = new OrderPo();
    }

    @Test
    void testGetOrderStatus() {
        assertThat(orderPoUnderTest.getOrderStatus()).isEqualTo(OrderStatus.CREATED);
    }

    @Test
    void testSetOrderStatus() {
        // Setup
        // Run the test
        orderPoUnderTest.setOrderStatus(OrderStatus.CREATED);

        // Verify the results
    }
}
