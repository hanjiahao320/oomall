package cn.edu.xmu.oomall.order.service;

import cn.edu.xmu.javaee.core.exception.BusinessException;
import cn.edu.xmu.oomall.order.controller.vo.OrderVo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class OrderServiceTest {

    private OrderService orderServiceUnderTest;

    @BeforeEach
    void setUp() {
        orderServiceUnderTest = new OrderService();
    }

    @Test
    void testGetOrderById() {
        // Setup
        final OrderVo expectedResult = new OrderVo();
        expectedResult.setConsignee("consignee");
        expectedResult.setAddress("address");
        expectedResult.setOrderId(0L);
        expectedResult.setCustomerId(0L);
        expectedResult.setStatus(0);

        // Run the test
        final OrderVo result = orderServiceUnderTest.getOrderById(0L, 0L);

        // Verify the results
        assertThat(result).isEqualTo(expectedResult);
    }

    @Test
    void testGetOrderById_ThrowsBusinessException() {
        // Setup
        // Run the test
        assertThatThrownBy(() -> orderServiceUnderTest.getOrderById(0L, 0L)).isInstanceOf(BusinessException.class);
    }

    @Test
    void testPayOrder() {
        // Setup
        // Run the test
        orderServiceUnderTest.payOrder(0L, 0L);

        // Verify the results
    }

    @Test
    void testPayOrder_ThrowsBusinessException() {
        // Setup
        // Run the test
        assertThatThrownBy(() -> orderServiceUnderTest.payOrder(0L, 0L)).isInstanceOf(BusinessException.class);
    }

    @Test
    void testCancelOrder() {
        // Setup
        // Run the test
        orderServiceUnderTest.cancelOrder(0L, 0L);

        // Verify the results
    }

    @Test
    void testCancelOrder_ThrowsBusinessException() {
        // Setup
        // Run the test
        assertThatThrownBy(() -> orderServiceUnderTest.cancelOrder(0L, 0L)).isInstanceOf(BusinessException.class);
    }

    @Test
    void testSearchOrders() {
        // Setup
        final OrderVo orderVo = new OrderVo();
        orderVo.setConsignee("consignee");
        orderVo.setAddress("address");
        orderVo.setOrderId(0L);
        orderVo.setCustomerId(0L);
        orderVo.setStatus(0);
        final List<OrderVo> expectedResult = List.of(orderVo);

        // Run the test
        final List<OrderVo> result = orderServiceUnderTest.searchOrders("itemName", 0L, 0, 0);

        // Verify the results
        assertThat(result).isEqualTo(expectedResult);
    }

    @Test
    void testSearchOrders_ThrowsBusinessException() {
        // Setup
        // Run the test
        assertThatThrownBy(() -> orderServiceUnderTest.searchOrders("itemName", 0L, 0, 0))
                .isInstanceOf(BusinessException.class);
    }
}
