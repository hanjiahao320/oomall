package cn.edu.xmu.oomall.order.controller.dto;

import org.junit.jupiter.api.BeforeEach;

class OrderItemDtoTest {

    private OrderItemDto orderItemDtoUnderTest;

    @BeforeEach
    void setUp() {
        orderItemDtoUnderTest = new OrderItemDto();
    }
}
