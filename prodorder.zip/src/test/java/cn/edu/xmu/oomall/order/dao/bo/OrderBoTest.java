package cn.edu.xmu.oomall.order.dao.bo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.List;

class OrderBoTest {

    private OrderBo orderBoUnderTest;

    @BeforeEach
    void setUp() {
        orderBoUnderTest = new OrderBo(0L, 0L, "creatorName", 0L, "modifierName", LocalDateTime.of(2020, 1, 1, 0, 0, 0),
                LocalDateTime.of(2020, 1, 1, 0, 0, 0), 0L, 0L, 0L, 0, "orderSn", 0L, "consignee", 0L, "address",
                "mobile", "message", 0L, 0L, List.of(OrderItemBo.builder()
                .id(0L)
                .creatorId(0L)
                .creatorName("creatorName")
                .modifierId(0L)
                .modifierName("modifierName")
                .gmtCreate(LocalDateTime.of(2020, 1, 1, 0, 0, 0))
                .gmtModified(LocalDateTime.of(2020, 1, 1, 0, 0, 0))
                .build()));
    }

    @Test
    void testSetGmtCreate() {
        orderBoUnderTest.setGmtCreate(LocalDateTime.of(2020, 1, 1, 0, 0, 0));
    }

    @Test
    void testSetGmtModified() {
        orderBoUnderTest.setGmtModified(LocalDateTime.of(2020, 1, 1, 0, 0, 0));
    }
}
