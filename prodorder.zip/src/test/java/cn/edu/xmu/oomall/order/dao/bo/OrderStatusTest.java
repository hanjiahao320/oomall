package cn.edu.xmu.oomall.order.dao.bo;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class OrderStatusTest {

    @Test
    void testGetCode() {
        assertThat(OrderStatus.CREATED.getCode()).isEqualTo(0);
        assertThat(OrderStatus.PAID.getCode()).isEqualTo(0);
        assertThat(OrderStatus.SHIPPED.getCode()).isEqualTo(0);
        assertThat(OrderStatus.DELIVERED.getCode()).isEqualTo(0);
        assertThat(OrderStatus.CANCELLED.getCode()).isEqualTo(0);
    }

    @Test
    void testGetDescription() {
        assertThat(OrderStatus.CREATED.getDescription()).isEqualTo("description");
        assertThat(OrderStatus.PAID.getDescription()).isEqualTo("description");
        assertThat(OrderStatus.SHIPPED.getDescription()).isEqualTo("description");
        assertThat(OrderStatus.DELIVERED.getDescription()).isEqualTo("description");
        assertThat(OrderStatus.CANCELLED.getDescription()).isEqualTo("description");
    }

    @Test
    void testFromCode() {
        assertThat(OrderStatus.fromCode(0)).isEqualTo(OrderStatus.CREATED);
    }
}
