package cn.edu.xmu.oomall.order.controller.dto;

import lombok.Data;
import java.util.Date;

@Data
public class OrderItemDto {
    private Long itemId;
    private Long onsaleId;
    private Integer quantity;
    private String itemName;
}