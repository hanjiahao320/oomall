package cn.edu.xmu.oomall.order.dao;

import org.apache.ibatis.annotations.*;
import cn.edu.xmu.oomall.order.service.po.OrderItemPo;
import java.util.List;

@Mapper
public interface OrderItemDao {

    @Select("SELECT * FROM order_items WHERE order_id = #{orderId}")
    List<OrderItemPo> getOrderItemsByOrderId(Long orderId);

    @Insert("<script>" +
            "INSERT INTO order_items (order_id, item_id, onsale_id, quantity, item_name) VALUES " +
            "<foreach collection='orderItems' item='item' separator=','>" +
            "(#{item.orderId}, #{item.itemId}, #{item.onsaleId}, #{item.quantity}, #{item.itemName})" +
            "</foreach>" +
            "</script>")
    int insertOrderItems(@Param("orderItems") List<OrderItemPo> orderItems);
}
