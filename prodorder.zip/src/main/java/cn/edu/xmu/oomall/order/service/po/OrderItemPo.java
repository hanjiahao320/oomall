package cn.edu.xmu.oomall.order.service.po;

import java.util.Date;
import lombok.Data;

@Data
public class OrderItemPo {
    private Long orderItemId;
    private Long orderId;
    private Long itemId;
    private Long onsaleId;
    private Integer quantity;
    private String itemName;
    private Date createdTime;
    private Date modifiedTime;
}
