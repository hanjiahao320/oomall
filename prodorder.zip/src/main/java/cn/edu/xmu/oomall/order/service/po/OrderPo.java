package cn.edu.xmu.oomall.order.service.po;

import lombok.Data;
import java.util.Date;
import cn.edu.xmu.oomall.order.dao.bo.OrderStatus;
import cn.edu.xmu.javaee.core.exception.BusinessException;
import cn.edu.xmu.oomall.order.dao.OrderDao;
import cn.edu.xmu.javaee.core.model.ReturnNo;
import java.lang.Exception;

@Data
public class OrderPo {
    private Long orderId;
    private Long userId;
    private String consignee;
    private String address;
    private Integer status;  // 数据库中的状态字段，仍然是 Integer 类型
    private Date createdTime;
    private Date modifiedTime;
    private OrderDao orderDao;

    // 转换 status 为枚举类型
    public OrderStatus getOrderStatus() {
        if (status != null) {
            return OrderStatus.fromCode(status);
        }
        return null;
    }

    // 将枚举类型的状态设置到 status 字段
    public void setOrderStatus(OrderStatus orderStatus) {
        if (orderStatus != null) {
            this.status = orderStatus.getCode();
        } else {
            this.status = null; // 如果状态为 null，则清空状态字段
        }
    }


}
