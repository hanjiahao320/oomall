package cn.edu.xmu.oomall.order.dao;

import org.apache.ibatis.annotations.*;
import cn.edu.xmu.oomall.order.service.po.OrderPo;
import java.util.List;

public interface OrderDao {

    @Select("SELECT * FROM orders WHERE order_id = #{orderId}")
    OrderPo getOrderById(Long orderId);

    @Select("SELECT * FROM orders WHERE customer_id = #{customerId} LIMIT #{offset}, #{limit}")
    List<OrderPo> searchOrders(@Param("itemName") String itemName,
                               @Param("customerId") Long customerId,
                               @Param("offset") int offset,
                               @Param("limit") int limit);

    // 修改 updateOrder 方法，接受一个 OrderPo 对象
    @Update("UPDATE orders SET status = #{orderPo.status}, modified_time = NOW(), " +
            "consignee = #{orderPo.consignee}, address = #{orderPo.address} WHERE order_id = #{orderPo.orderId}")
    int updateOrder(@Param("orderPo") OrderPo orderPo);

    // 如果只是更新状态，可以保留原有的 updateOrderStatus 方法
    @Update("UPDATE orders SET status = #{status}, modified_time = NOW() WHERE order_id = #{orderId}")
    int updateOrderStatus(@Param("orderId") Long orderId, @Param("status") Integer status);
}
