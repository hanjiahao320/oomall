package cn.edu.xmu.oomall.order.controller.dto;

import lombok.Data;
import java.util.List;

@Data
public class OrderDto {
    private Long orderId;
    private Long customerId;
    private String consignee;
    private String address;
    private Integer status; // 可以定义为枚举类型
    private List<OrderItemDto> orderItems; // 订单项 DTO
}