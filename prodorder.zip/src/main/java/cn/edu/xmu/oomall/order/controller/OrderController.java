package cn.edu.xmu.oomall.order.controller;

import cn.edu.xmu.javaee.core.aop.LoginUser;
import cn.edu.xmu.javaee.core.exception.BusinessException;
import cn.edu.xmu.javaee.core.model.InternalReturnObject;
import cn.edu.xmu.javaee.core.model.ReturnNo;
import cn.edu.xmu.javaee.core.model.ReturnObject;
import cn.edu.xmu.javaee.core.model.dto.UserDto;
import cn.edu.xmu.oomall.order.controller.vo.OrderVo;
import cn.edu.xmu.oomall.order.service.OrderService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.stream.Collectors;
import cn.edu.xmu.oomall.order.service.po.OrderItemPo;
import cn.edu.xmu.oomall.order.service.po.OrderPo;
import cn.edu.xmu.oomall.order.dao.*;
import cn.edu.xmu.oomall.order.dao.bo.*;
import cn.edu.xmu.oomall.order.controller.vo.*;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@RestController
@RequestMapping("/orders")
public class OrderController {

    private final OrderService orderService;

    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    // 查看订单
    @GetMapping("/{orderId}")
    public ResponseEntity<OrderVo> getOrderById(@PathVariable Long orderId, @LoginUser UserDto user) {
        try {
            OrderVo orderVo = orderService.getOrderById(orderId, user.getId());
            return ResponseEntity.ok(orderVo);  // 返回200和订单信息
        } catch (BusinessException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);  // 返回400和错误信息
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);  // 返回500服务器错误
        }
    }

    // 支付订单
    @PostMapping("/{orderId}/pay")
    public ResponseEntity<String> payOrder(@PathVariable Long orderId, @LoginUser UserDto user) {
        try {
            orderService.payOrder(orderId, user.getId());
            return ResponseEntity.status(HttpStatus.OK).body("支付成功");  // 返回200和支付成功消息
        } catch (BusinessException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("支付失败: " + e.getMessage());  // 返回400和错误信息
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("支付失败: " + e.getMessage());  // 返回500服务器错误
        }
    }

    // 取消订单
    @PostMapping("/{orderId}/cancel")
    public ResponseEntity<String> cancelOrder(@PathVariable Long orderId, @LoginUser UserDto user) {
        try {
            orderService.cancelOrder(orderId, user.getId());
            return ResponseEntity.status(HttpStatus.OK).body("订单取消成功");  // 返回200和取消成功消息
        } catch (BusinessException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("取消订单失败: " + e.getMessage());  // 返回400和错误信息
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("取消订单失败: " + e.getMessage());  // 返回500服务器错误
        }
    }

    // 搜索订单
    @GetMapping
    public ResponseEntity<List<OrderVo>> searchOrders(
            @RequestParam(value = "itemName") String itemName,
            @RequestParam(value = "customerId") Long customerId,
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int size) {
        try {
            List<OrderVo> orders = orderService.searchOrders(itemName, customerId, page, size);
            return ResponseEntity.ok(orders);  // 返回200和订单列表
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);  // 返回500服务器错误
        }
    }
}
