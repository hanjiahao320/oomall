//School of Informatics Xiamen University, GPL-3.0 license

package cn.edu.xmu.oomall.order.service;

import cn.edu.xmu.javaee.core.exception.BusinessException;
import cn.edu.xmu.javaee.core.model.ReturnNo;
import cn.edu.xmu.oomall.order.service.po.OrderItemPo;
import cn.edu.xmu.oomall.order.service.po.OrderPo;
import cn.edu.xmu.oomall.order.dao.*;
import cn.edu.xmu.oomall.order.dao.bo.*;
import cn.edu.xmu.oomall.order.controller.vo.*;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import lombok.*;

@Service
@RequiredArgsConstructor
public class OrderService {

    private  OrderDao orderDao;
    private  OrderItemDao orderItemDao;

    // 查看订单
    public OrderVo getOrderById(Long orderId, Long userId) throws BusinessException {
        // 获取订单PO
        OrderPo orderPo = orderDao.getOrderById(orderId);
        if (orderPo == null || !orderPo.getUserId().equals(userId)) {
            throw new BusinessException(ReturnNo.RESOURCE_ID_NOTEXIST, "订单不存在或权限不足");
        }

        // 获取订单项PO
        List<OrderItemPo> orderItemPos = orderItemDao.getOrderItemsByOrderId(orderId);

        // 转换为BO
        OrderBo orderBo = convertToOrderBo(orderPo, orderItemPos);

        // 转换为VO
        return convertToOrderVo(orderBo);
    }

    // 支付订单
    public void payOrder(Long orderId, Long userId) throws BusinessException {
        // 获取订单PO
        OrderPo orderPo = orderDao.getOrderById(orderId);
        if (orderPo == null || !orderPo.getUserId().equals(userId)) {
            throw new BusinessException(ReturnNo.RESOURCE_ID_NOTEXIST, "订单不存在或权限不足");
        }

        // 更改订单状态为已支付
        orderPo.setStatus(1);
        orderDao.updateOrder(orderPo);
    }

    // 取消订单
    public void cancelOrder(Long orderId, Long userId) throws BusinessException {
        // 获取订单PO
        OrderPo orderPo = orderDao.getOrderById(orderId);
        if (orderPo == null || !orderPo.getUserId().equals(userId)) {
            throw new BusinessException(ReturnNo.RESOURCE_ID_NOTEXIST, "订单不存在或权限不足");
        }
        // 更改订单状态为已取消
        orderPo.setStatus(4);
        orderDao.updateOrder(orderPo);
    }

    // 搜索订单
    public List<OrderVo> searchOrders(String itemName, Long customerId, int page, int size) throws BusinessException {
        List<OrderPo> orderPos = orderDao.searchOrders(itemName, customerId, page, size);
        List<OrderVo> orderVos = new ArrayList<>();
        for (OrderPo orderPo : orderPos) {
            // 获取订单项
            List<OrderItemPo> orderItemPos = orderItemDao.getOrderItemsByOrderId(orderPo.getOrderId());
            // 转换为BO
            OrderBo orderBo = convertToOrderBo(orderPo, orderItemPos);
            // 转换为VO
            orderVos.add(convertToOrderVo(orderBo));
        }
        return orderVos;
    }

    // 将PO转换为BO
    private OrderBo convertToOrderBo(OrderPo orderPo, List<OrderItemPo> orderItemPos) {
        OrderBo orderBo = new OrderBo();
        orderBo.setOrderId(orderPo.getOrderId());
        orderBo.setCustomerId(orderPo.getUserId());
        orderBo.setStatus(orderPo.getStatus());
        orderBo.setConsignee(orderPo.getConsignee());
        orderBo.setAddress(orderPo.getAddress());

        List<OrderItemBo> orderItemBos = new ArrayList<>();
        for (OrderItemPo orderItemPo : orderItemPos) {
            OrderItemBo orderItemBo = new OrderItemBo();
            orderItemBo.setOrderItemId(orderItemPo.getItemId());
            orderItemBo.setOnsaleId(orderItemPo.getOnsaleId());
            orderItemBo.setQuantity(orderItemPo.getQuantity());
            orderItemBo.setName(orderItemPo.getItemName());
            orderItemBos.add(orderItemBo);
        }
        orderBo.setOrderItems(orderItemBos);
        return orderBo;
    }

    // 将BO转换为VO
    private OrderVo convertToOrderVo(OrderBo orderBo) {
        OrderVo orderVo = new OrderVo();
        orderVo.setOrderId(orderBo.getOrderId());
        orderVo.setCustomerId(orderBo.getCustomerId());
        orderVo.setStatus(orderBo.getStatus());
        orderVo.setConsignee(orderBo.getConsignee());
        orderVo.setAddress(orderBo.getAddress());

        List<OrderItemVo> orderItemVos = new ArrayList<>();
        for (OrderItemBo orderItemBo : orderBo.getOrderItems()) {
            OrderItemVo orderItemVo = new OrderItemVo();
            orderItemVo.setItemId(orderItemBo.getOrderItemId());
            orderItemVo.setOnsaleId(orderItemBo.getOnsaleId());
            orderItemVo.setQuantity(orderItemBo.getQuantity());
            orderItemVo.setItemName(orderItemBo.getName());
            orderItemVos.add(orderItemVo);
        }
        orderVo.setOrderItems(orderItemVos);
        return orderVo;
    }
}
