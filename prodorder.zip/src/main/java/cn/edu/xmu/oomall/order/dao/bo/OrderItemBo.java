package cn.edu.xmu.oomall.order.dao.bo;

import cn.edu.xmu.javaee.core.model.bo.OOMallObject;
import lombok.*;

import java.io.Serializable;
import java.time.LocalDateTime;

@ToString(callSuper = true)
@NoArgsConstructor
public class OrderItemBo extends OOMallObject implements Serializable {

    @Builder
    public OrderItemBo(Long id, Long creatorId, String creatorName, Long modifierId, String modifierName, LocalDateTime gmtCreate,Integer status, LocalDateTime gmtModified, Long orderId,Long orderItemId, Long onsaleId, Integer quantity, Long price, Long discountPrice, Long point, String name, Long actId, Long couponId, Byte commented, long originPrice) {
        super(id, creatorId, creatorName, modifierId, modifierName, gmtCreate, gmtModified);
        this.orderId = orderId;
        this.orderItemId = orderItemId;
        this.onsaleId = onsaleId;
        this.quantity = quantity;
        this.price = price;
        this.discountPrice = discountPrice;
        this.point = point;
        this.name = name;
        this.actId = actId;
        this.couponId = couponId;
        this.commented = commented;
        this.status = status; // 新增
        this.originPrice = originPrice; // 新增
    }


    @Setter
    @Getter
    private Integer status;

    @Setter
    @Getter
    private Long orderItemId;

    @Setter
    @Getter
    private long originPrice;

    @Setter
    @Getter
    private Long orderId;

    @Setter
    @Getter
    private Long onsaleId;

    @Setter
    @Getter
    private Integer quantity;

    @Setter
    @Getter
    private Long price;

    @Setter
    @Getter
    private Long discountPrice;

    @Setter
    @Getter
    private Long point;

    @Setter
    @Getter
    private String name;

    @Setter
    @Getter
    private Long actId;

    @Setter
    @Getter
    private Long couponId;

    @Setter
    @Getter
    private Byte commented;

    @Override
    public void setGmtCreate(LocalDateTime gmtCreate) {

    }

    @Override
    public void setGmtModified(LocalDateTime gmtModified) {

    }
}