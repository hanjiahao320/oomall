package cn.edu.xmu.oomall.order.dao.bo;

import cn.edu.xmu.javaee.core.exception.BusinessException;
import cn.edu.xmu.javaee.core.model.ReturnNo;
import cn.edu.xmu.javaee.core.model.bo.OOMallObject;
import cn.edu.xmu.oomall.order.controller.vo.OrderVo;
import cn.edu.xmu.oomall.order.dao.OrderDao;
import cn.edu.xmu.oomall.order.service.po.OrderItemPo;
import cn.edu.xmu.oomall.order.service.po.OrderPo;
import lombok.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@ToString(callSuper = true)
@NoArgsConstructor
public class OrderBo extends OOMallObject {

    @Builder
    public OrderBo(Long id, Long creatorId, String creatorName, Long modifierId, String modifierName, LocalDateTime gmtCreate, LocalDateTime gmtModified, Long customerId,Long orderId,Long shopId,Integer status, String orderSn, Long pid, String consignee, Long regionId, String address, String mobile, String message, Long activityId, Long packageId, List<OrderItemBo> orderItems) {
        super(id, creatorId, creatorName, modifierId, modifierName, gmtCreate, gmtModified);
        this.customerId = customerId;
        this.shopId = shopId;
        this.orderId=orderId;
        this.status=status;
        this.orderSn = orderSn;
        this.pid = pid;
        this.consignee = consignee;
        this.regionId = regionId;
        this.address = address;
        this.mobile = mobile;
        this.message = message;
        this.activityId = activityId;
        this.packageId = packageId;
        this.orderItems = orderItems;
        this.point = 0;
    }

    @Setter
    @Getter
    private Long customerId;

    @Setter
    @Getter
    private Long orderId;

    @Setter
    @Getter
    private Long shopId;

    @Setter
    @Getter
    private Integer status;

    @Setter
    @Getter
    private String orderSn;

    @Setter
    @Getter
    private long point;

    @Setter
    @Getter
    private Long pid;

    @Setter
    @Getter
    private String consignee;

    @Setter
    private Long regionId;

    @Setter
    @Getter
    private String address;

    @Setter
    @Getter
    private String mobile;

    @Setter
    @Getter
    private String message;

    @Setter
    private Long activityId;

    @Setter
    private Long packageId;

    @Setter
    @Getter
    private List<OrderItemBo> orderItems;

    private OrderDao orderDao;

    @Override
    public void setGmtCreate(LocalDateTime gmtCreate) {

    }

    @Override
    public void setGmtModified(LocalDateTime gmtModified) {

    }


    // 支付订单
    public void payOrder(Long orderId, Long userId) throws BusinessException {
        // 获取订单PO
        OrderPo orderPo = orderDao.getOrderById(orderId);
        if (orderPo == null || !orderPo.getUserId().equals(userId)) {
            throw new BusinessException(ReturnNo.RESOURCE_ID_NOTEXIST, "订单不存在或权限不足");
        }

        // 更改订单状态为已支付
        orderPo.setStatus(1);
        orderDao.updateOrder(orderPo);
    }

    // 取消订单
    public void cancelOrder(Long orderId, Long userId) throws BusinessException {
        // 获取订单PO
        OrderPo orderPo = orderDao.getOrderById(orderId);
        if (orderPo == null || !orderPo.getUserId().equals(userId)) {
            throw new BusinessException(ReturnNo.RESOURCE_ID_NOTEXIST, "订单不存在或权限不足");
        }
        // 更改订单状态为已取消
        orderPo.setStatus(4);
        orderDao.updateOrder(orderPo);
    }


}
