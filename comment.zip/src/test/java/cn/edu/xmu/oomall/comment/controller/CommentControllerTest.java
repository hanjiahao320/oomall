package cn.edu.xmu.oomall.comment.controller;

import cn.edu.xmu.oomall.comment.controller.dto.CommentDTO;
import cn.edu.xmu.oomall.comment.controller.vo.CommentVo;
import cn.edu.xmu.oomall.comment.controller.vo.PageVo;
import cn.edu.xmu.oomall.comment.service.CommentService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Collections;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(CommentController.class)
class CommentControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CommentService mockCommentService;

    @Test
    void testAddComment() throws Exception {
        // Setup
        // Run the test and verify the results
        mockMvc.perform(post("/comments/add")
                        .content("content").contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().json("{}", true));
        verify(mockCommentService).addComment(any(CommentDTO.class));
    }

    @Test
    void testFollowUpComment() throws Exception {
        // Setup
        // Run the test and verify the results
        mockMvc.perform(post("/comments/followUp")
                        .content("content").contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().json("{}", true));
        verify(mockCommentService).additionalComment(any(CommentDTO.class));
    }

    @Test
    void testDeleteComment() throws Exception {
        // Setup
        // Run the test and verify the results
        mockMvc.perform(delete("/comments/delete/{commentId}", 0)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().json("{}", true));
        verify(mockCommentService).deleteComment(0L);
    }

    @Test
    void testReplyToComment() throws Exception {
        // Setup
        // Run the test and verify the results
        mockMvc.perform(post("/comments/reply")
                        .content("content").contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().json("{}", true));
        verify(mockCommentService).replyToComment(any(CommentDTO.class));
    }

    @Test
    void testAuditComment() throws Exception {
        // Setup
        // Run the test and verify the results
        mockMvc.perform(put("/comments/audit/{commentId}", 0)
                        .param("status", "0")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().json("{}", true));
        verify(mockCommentService).auditComment(0L, 0);
    }

    @Test
    void testGetComments() throws Exception {
        // Setup
        // Configure CommentService.getCommentsByProductId(...).
        final CommentVo commentVo = new CommentVo();
        commentVo.setCommentId(0L);
        commentVo.setUserId(0L);
        commentVo.setUserName("userName");
        commentVo.setProductId(0L);
        commentVo.setProductName("productName");
        final List<CommentVo> commentVos = List.of(commentVo);
        when(mockCommentService.getCommentsByProductId(any(PageVo.class), eq(0L))).thenReturn(commentVos);

        // Run the test and verify the results
        mockMvc.perform(get("/comments/list")
                        .param("productId", "0")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().json("{}", true));
    }

    @Test
    void testGetComments_CommentServiceReturnsNoItems() throws Exception {
        // Setup
        when(mockCommentService.getCommentsByProductId(any(PageVo.class), eq(0L))).thenReturn(Collections.emptyList());

        // Run the test and verify the results
        mockMvc.perform(get("/comments/list")
                        .param("productId", "0")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().json("[]", true));
    }
}
