package cn.edu.xmu.oomall.comment.dao;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CommentDAOTest {

    @Test
    void insertComment() {
    }

    @Test
    void getCommentsByProductId() {
    }

    @Test
    void updateComment() {
    }

    @Test
    void deleteComment() {
    }

    @Test
    void replyToComment() {
    }

    @Test
    void auditComment() {
    }
}