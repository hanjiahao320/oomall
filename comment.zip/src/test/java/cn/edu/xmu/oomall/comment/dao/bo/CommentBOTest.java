package cn.edu.xmu.oomall.comment.dao.bo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class CommentBOTest {

    private CommentBO commentBOUnderTest;

    @BeforeEach
    void setUp() {
        commentBOUnderTest = new CommentBO();
        commentBOUnderTest.setCommentId(0L);
        commentBOUnderTest.setUserName("userName");
        commentBOUnderTest.setProductName("productName");
    }

    @Test
    void testUserIdGetterAndSetter() {
        final Long userId = 0L;
        commentBOUnderTest.setUserId(userId);
        assertThat(commentBOUnderTest.getUserId()).isEqualTo(userId);
    }

    @Test
    void testProductIdGetterAndSetter() {
        final Long productId = 0L;
        commentBOUnderTest.setProductId(productId);
        assertThat(commentBOUnderTest.getProductId()).isEqualTo(productId);
    }

    @Test
    void testRatingGetterAndSetter() {
        final Integer rating = 0;
        commentBOUnderTest.setRating(rating);
        assertThat(commentBOUnderTest.getRating()).isEqualTo(rating);
    }

    @Test
    void testContentGetterAndSetter() {
        final String content = "content";
        commentBOUnderTest.setContent(content);
        assertThat(commentBOUnderTest.getContent()).isEqualTo(content);
    }

    @Test
    void testGetCommentId() {
        assertThat(commentBOUnderTest.getCommentId()).isEqualTo(0L);
    }

    @Test
    void testGetUserName() {
        assertThat(commentBOUnderTest.getUserName()).isNull();
    }

    @Test
    void testGetProductName() {
        assertThat(commentBOUnderTest.getProductName()).isNull();
    }
}
