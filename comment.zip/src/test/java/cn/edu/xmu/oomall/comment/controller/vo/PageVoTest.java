package cn.edu.xmu.oomall.comment.controller.vo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class PageVoTest {

    private PageVo pageVoUnderTest;

    @BeforeEach
    void setUp() {
        pageVoUnderTest = new PageVo(0, 0);
    }

    @Test
    void testGetPage() {
        assertThat(pageVoUnderTest.getPage()).isEqualTo(0);
    }

    @Test
    void testSetPage() {
        // Setup
        // Run the test
        pageVoUnderTest.setPage(0);

        // Verify the results
    }

    @Test
    void testLimitGetterAndSetter() {
        final int limit = 0;
        pageVoUnderTest.setLimit(limit);
        assertThat(pageVoUnderTest.getLimit()).isEqualTo(limit);
    }

    @Test
    void testOffsetGetterAndSetter() {
        final int offset = 0;
        pageVoUnderTest.setOffset(offset);
        assertThat(pageVoUnderTest.getOffset()).isEqualTo(offset);
    }

    @Test
    void testGetTotal() {
        assertThat(pageVoUnderTest.getTotal()).isEqualTo(0L);
    }

    @Test
    void testSetTotal() {
        // Setup
        // Run the test
        pageVoUnderTest.setTotal(0L);

        // Verify the results
    }

    @Test
    void testGetTotalPages() {
        assertThat(pageVoUnderTest.getTotalPages()).isEqualTo(0);
    }

    @Test
    void testSortGetterAndSetter() {
        final String sort = "sort";
        pageVoUnderTest.setSort(sort);
        assertThat(pageVoUnderTest.getSort()).isEqualTo(sort);
    }
}
