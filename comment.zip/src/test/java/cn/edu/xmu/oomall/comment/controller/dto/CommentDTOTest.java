package cn.edu.xmu.oomall.comment.controller.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(MockitoExtension.class)
class CommentDTOTest {

    @Mock
    private List<String> mockImageUrls;

    private CommentDTO commentDTOUnderTest;

    @BeforeEach
    void setUp() {
        commentDTOUnderTest = new CommentDTO();
        commentDTOUnderTest.setImageUrls(mockImageUrls);
    }

    @Test
    void testUserIdGetterAndSetter() {
        final Long userId = 0L;
        commentDTOUnderTest.setUserId(userId);
        assertThat(commentDTOUnderTest.getUserId()).isEqualTo(userId);
    }

    @Test
    void testGetCommentId() {
        assertThat(commentDTOUnderTest.getCommentId()).isEqualTo(0L);
    }

    @Test
    void testProductIdGetterAndSetter() {
        final Long productId = 0L;
        commentDTOUnderTest.setProductId(productId);
        assertThat(commentDTOUnderTest.getProductId()).isEqualTo(productId);
    }

    @Test
    void testGetUserName() {
        assertThat(commentDTOUnderTest.getUserName()).isEqualTo("userName");
    }

    @Test
    void testGetProductName() {
        assertThat(commentDTOUnderTest.getProductName()).isEqualTo("productName");
    }

    @Test
    void testRatingGetterAndSetter() {
        final Integer rating = 0;
        commentDTOUnderTest.setRating(rating);
        assertThat(commentDTOUnderTest.getRating()).isEqualTo(rating);
    }

    @Test
    void testContentGetterAndSetter() {
        final String content = "content";
        commentDTOUnderTest.setContent(content);
        assertThat(commentDTOUnderTest.getContent()).isEqualTo(content);
    }

    @Test
    void testGetImageUrls() {
        assertThat(commentDTOUnderTest.getImageUrls()).isEqualTo(mockImageUrls);
    }

    @Test
    void testReplyToGetterAndSetter() {
        final Long replyTo = 0L;
        commentDTOUnderTest.setReplyTo(replyTo);
        assertThat(commentDTOUnderTest.getReplyTo()).isEqualTo(replyTo);
    }

    @Test
    void testStatusGetterAndSetter() {
        final Integer status = 0;
        commentDTOUnderTest.setStatus(status);
        assertThat(commentDTOUnderTest.getStatus()).isEqualTo(status);
    }
}
