package cn.edu.xmu.oomall.comment.service;

import cn.edu.xmu.oomall.comment.controller.dto.CommentDTO;
import cn.edu.xmu.oomall.comment.controller.vo.CommentVo;
import cn.edu.xmu.oomall.comment.controller.vo.PageVo;
import cn.edu.xmu.oomall.comment.dao.CommentDAO;
import cn.edu.xmu.oomall.comment.dao.bo.CommentBO;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CommentServiceTest {

    @Mock
    private CommentDAO mockCommentDAO;

    @InjectMocks
    private CommentService commentServiceUnderTest;

    @Test
    void testAddComment() {
        // Setup
        final CommentDTO commentDTO = new CommentDTO();
        commentDTO.setUserId(0L);
        commentDTO.setProductId(0L);
        commentDTO.setRating(0);
        commentDTO.setContent("content");
        commentDTO.setImageUrls(List.of("value"));

        // Run the test
        commentServiceUnderTest.addComment(commentDTO);

        // Verify the results
        verify(mockCommentDAO).insertComment(any(CommentBO.class));
    }

    @Test
    void testGetCommentsByProductId() {
        // Setup
        final PageVo pageVo = new PageVo(0, 0);

        // Configure CommentDAO.getCommentsByProductId(...).
        final CommentBO commentBO = new CommentBO();
        commentBO.setUserId(0L);
        commentBO.setUserName("userName");
        commentBO.setCommentId(0L);
        commentBO.setProductId(0L);
        commentBO.setProductName("productName");
        commentBO.setRating(0);
        commentBO.setContent("content");
        final List<CommentBO> commentBOS = List.of(commentBO);
        when(mockCommentDAO.getCommentsByProductId(any(PageVo.class), eq(0L))).thenReturn(commentBOS);

        // Run the test
        final List<CommentVo> result = commentServiceUnderTest.getCommentsByProductId(pageVo, 0L);

        // Verify the results
    }

    @Test
    void testGetCommentsByProductId_CommentDAOReturnsNoItems() {
        // Setup
        final PageVo pageVo = new PageVo(0, 0);
        when(mockCommentDAO.getCommentsByProductId(any(PageVo.class), eq(0L))).thenReturn(Collections.emptyList());

        // Run the test
        final List<CommentVo> result = commentServiceUnderTest.getCommentsByProductId(pageVo, 0L);

        // Verify the results
        assertThat(result).isEqualTo(Collections.emptyList());
    }

    @Test
    void testAdditionalComment() {
        // Setup
        final CommentDTO commentDTO = new CommentDTO();
        commentDTO.setUserId(0L);
        commentDTO.setProductId(0L);
        commentDTO.setRating(0);
        commentDTO.setContent("content");
        commentDTO.setImageUrls(List.of("value"));

        // Run the test
        commentServiceUnderTest.additionalComment(commentDTO);

        // Verify the results
        verify(mockCommentDAO).updateComment(any(CommentBO.class));
    }

    @Test
    void testDeleteComment() {
        // Setup
        // Run the test
        commentServiceUnderTest.deleteComment(0L);

        // Verify the results
        verify(mockCommentDAO).deleteComment(0L);
    }

    @Test
    void testReplyToComment() {
        // Setup
        final CommentDTO commentDTO = new CommentDTO();
        commentDTO.setUserId(0L);
        commentDTO.setProductId(0L);
        commentDTO.setRating(0);
        commentDTO.setContent("content");
        commentDTO.setImageUrls(List.of("value"));

        // Run the test
        commentServiceUnderTest.replyToComment(commentDTO);

        // Verify the results
        verify(mockCommentDAO).replyToComment(any(CommentBO.class));
    }

    @Test
    void testAuditComment() {
        // Setup
        // Run the test
        commentServiceUnderTest.auditComment(0L, 0);

        // Verify the results
        verify(mockCommentDAO).auditComment(0L, 0);
    }

    @Test
    void testSomeServiceMethod() {
        // Setup
        // Run the test
        commentServiceUnderTest.someServiceMethod();

        // Verify the results
    }
}
