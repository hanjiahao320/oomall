package cn.edu.xmu.oomall.comment.controller.vo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Date;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(MockitoExtension.class)
class CommentVoTest {

    @Mock
    private Date mockCreateTime;
    @Mock
    private Date mockUpdateTime;
    @Mock
    private List<ReplyVo> mockReplies;

    private CommentVo commentVoUnderTest;

    @BeforeEach
    void setUp() {
        commentVoUnderTest = new CommentVo();
        commentVoUnderTest.setCreateTime(mockCreateTime);
        commentVoUnderTest.setUpdateTime(mockUpdateTime);
        commentVoUnderTest.setReplies(mockReplies);
    }

    @Test
    void testCommentIdGetterAndSetter() {
        final Long commentId = 0L;
        commentVoUnderTest.setCommentId(commentId);
        assertThat(commentVoUnderTest.getCommentId()).isEqualTo(commentId);
    }

    @Test
    void testUserIdGetterAndSetter() {
        final Long userId = 0L;
        commentVoUnderTest.setUserId(userId);
        assertThat(commentVoUnderTest.getUserId()).isEqualTo(userId);
    }

    @Test
    void testUserNameGetterAndSetter() {
        final String userName = "userName";
        commentVoUnderTest.setUserName(userName);
        assertThat(commentVoUnderTest.getUserName()).isEqualTo(userName);
    }

    @Test
    void testProductIdGetterAndSetter() {
        final Long productId = 0L;
        commentVoUnderTest.setProductId(productId);
        assertThat(commentVoUnderTest.getProductId()).isEqualTo(productId);
    }

    @Test
    void testProductNameGetterAndSetter() {
        final String productName = "productName";
        commentVoUnderTest.setProductName(productName);
        assertThat(commentVoUnderTest.getProductName()).isEqualTo(productName);
    }

    @Test
    void testRatingGetterAndSetter() {
        final Integer rating = 0;
        commentVoUnderTest.setRating(rating);
        assertThat(commentVoUnderTest.getRating()).isEqualTo(rating);
    }

    @Test
    void testContentGetterAndSetter() {
        final String content = "content";
        commentVoUnderTest.setContent(content);
        assertThat(commentVoUnderTest.getContent()).isEqualTo(content);
    }

    @Test
    void testGetCreateTime() {
        assertThat(commentVoUnderTest.getCreateTime()).isEqualTo(mockCreateTime);
    }

    @Test
    void testGetUpdateTime() {
        assertThat(commentVoUnderTest.getUpdateTime()).isEqualTo(mockUpdateTime);
    }

    @Test
    void testReplyCountGetterAndSetter() {
        final Integer replyCount = 0;
        commentVoUnderTest.setReplyCount(replyCount);
        assertThat(commentVoUnderTest.getReplyCount()).isEqualTo(replyCount);
    }

    @Test
    void testGetReplies() {
        assertThat(commentVoUnderTest.getReplies()).isEqualTo(mockReplies);
    }
}
