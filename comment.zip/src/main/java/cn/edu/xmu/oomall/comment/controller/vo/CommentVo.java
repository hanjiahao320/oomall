package cn.edu.xmu.oomall.comment.controller.vo;

import java.util.Date;
import java.util.List;

// CommentVo 类作为公共类，必须在 CommentVo.java 文件中声明
public class CommentVo {

    private Long commentId; // 评论ID
    private Long userId; // 用户ID
    private String userName; // 用户名
    private Long productId; // 商品ID
    private String productName; // 商品名称
    private Integer rating; // 评分
    private String content; // 评论内容
    private Date createTime; // 创建时间
    private Date updateTime; // 更新时间
    private Integer replyCount; // 回复数量
    private List<ReplyVo> replies; // 回复列表

    // Getters and Setters
    public Long getCommentId() {
        return commentId;
    }

    public void setCommentId(Long commentId) {
        this.commentId = commentId;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Integer getRating() {
        return rating;
    }

    public void setRating(Integer rating) {
        this.rating = rating;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getReplyCount() {
        return replyCount;
    }

    public void setReplyCount(Integer replyCount) {
        this.replyCount = replyCount;
    }

    public List<ReplyVo> getReplies() {
        return replies;
    }

    public void setReplies(List<ReplyVo> replies) {
        this.replies = replies;
    }
}

