package cn.edu.xmu.oomall.comment.controller.vo;

public class PageVo {
    private int page;//当前页码
    private int limit;  // 每页记录数
    private int offset; // 偏移量，表示从哪条记录开始

    private long total;//总记录数

    private int totalPages;//总页码数

    private String sort;//排序字段
    // Getters 和 Setters
    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
        this.offset = (page - 1) * limit; // 根据页码计算偏移量
    }
    public int getLimit() {
        return limit;
    }


    public void setLimit(int limit) {
        this.limit = limit;
    }

    public int getOffset() {
        return offset;
    }

    public void setOffset(int offset) {
        this.offset = offset;
    }

    public long getTotal() {
        return total;
    }

    public void setTotal(long total) {
        this.total = total;
        this.totalPages = (int) Math.ceil((double) total / limit); // 计算总页数
    }

    public int getTotalPages() {
        return totalPages;
    }

    public String getSort() {
        return sort;
    }

    public void setSort(String sort) {
        this.sort = sort;
    }

    // 可以增加构造函数以简化分页的创建
    public PageVo(int limit, int offset) {
        this.page = page;
        this.limit = limit;
        this.offset = (page - 1) * limit;
    }
}
