package cn.edu.xmu.oomall.comment.controller.dto;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.List;

public class CommentDTO {

    @NotNull(message = "用户ID不能为空")
    private Long userId;

    @NotNull(message = "评论ID不能为空")
    private Long commentId;

    @NotNull(message = "商品ID不能为空")
    private Long productId;

    @NotNull(message = "评分不能为空")
    private Integer rating;

    @Size(max = 500, message = "评论内容不能超过500字符")
    private String content;

    @Size(max = 500, message = "用户名")
    private String userName;

    @Size(max = 500, message = "产品名")
    private String productName;

    // 评论图片URL列表
    private List<String> imageUrls;

    // 被回复的评论ID
    private Long replyTo;

    // 评论的审核状态
    private Integer status;

    // Getters and Setters
    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getCommentId() {
        return commentId;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public String getUserName(){
        return userName;
    }

    public String getProductName(){
        return productName;
    }

    public Integer getRating() {
        return rating;
    }

    public void setRating(Integer rating) {
        this.rating = rating;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public List<String> getImageUrls() {
        return imageUrls;
    }

    public void setImageUrls(List<String> imageUrls) {
        this.imageUrls = imageUrls;
    }

    public Long getReplyTo() {
        return replyTo;
    }

    public void setReplyTo(Long replyTo) {
        this.replyTo = replyTo;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}