package cn.edu.xmu.oomall.comment.service;

import cn.edu.xmu.oomall.comment.controller.vo.CommentVo;
import cn.edu.xmu.oomall.comment.dao.bo.CommentBO;
import cn.edu.xmu.oomall.comment.controller.dto.CommentDTO;
import cn.edu.xmu.oomall.comment.dao.CommentDAO;
import cn.edu.xmu.oomall.comment.controller.vo.PageVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;
import java.lang.Exception;

@Service
public class CommentService {

    @Autowired
    private CommentDAO commentDAO;

    // 添加评论
    public void addComment(CommentDTO commentDTO) {
        try {
            CommentBO commentBO = convertToBO(commentDTO); // 手动转换
            commentDAO.insertComment(commentBO);
        } catch (Exception e) {
            throw new RuntimeException("评论添加失败", e); // 使用 RuntimeException 替代自定义异常
        }
    }

    // 根据商品ID和分页参数获取评论列表
    public List<CommentVo> getCommentsByProductId(PageVo pageVo, Long productId) {
        try {
            List<CommentBO> commentBOList = commentDAO.getCommentsByProductId(pageVo, productId);
            // 转换为Vo返回
            return commentBOList.stream()
                    .map(commentBO -> {
                        CommentVo commentVo = new CommentVo();
                        // 假设CommentVo和CommentBO字段一一对应，并且有相应的getter和setter
                        commentVo.setCommentId(commentBO.getCommentId());
                        commentVo.setUserId(commentBO.getUserId());
                        commentVo.setUserName(commentBO.getUserName());
                        commentVo.setProductId(commentBO.getProductId());
                        commentVo.setProductName(commentBO.getProductName());
                        commentVo.setRating(commentBO.getRating());
                        commentVo.setContent(commentBO.getContent());
                        // ... 设置其他字段 ...
                        return commentVo;
                    })
                    .collect(Collectors.toList());
        } catch (Exception e) {
            // 捕获异常并使用 RuntimeException
            throw new RuntimeException("获取评论列表失败", e);
        }
    }

    // 追评
    public void additionalComment(CommentDTO commentDTO) {
        try {
            CommentBO commentBO = convertToBO(commentDTO); // 手动转换
            commentDAO.updateComment(commentBO);
        } catch (Exception e) {
            throw new RuntimeException("追评失败", e); // 使用 RuntimeException 替代自定义异常
        }
    }

    // 删除评论
    public void deleteComment(Long commentId) {
        try {
            commentDAO.deleteComment(commentId);
        } catch (Exception e) {
            throw new RuntimeException("删除评论失败", e); // 使用 RuntimeException 替代自定义异常
        }
    }

    // 商家回复评论
    public void replyToComment(CommentDTO commentDTO) {
        try {
            CommentBO commentBO = convertToBO(commentDTO); // 手动转换
            commentDAO.replyToComment(commentBO);
        } catch (Exception e) {
            throw new RuntimeException("回复评论失败", e); // 使用 RuntimeException 替代自定义异常
        }
    }

    // 平台审核评论
    public void auditComment(Long commentId, Integer status) {
        try {
            commentDAO.auditComment(commentId, status);
        } catch (Exception e) {
            throw new RuntimeException("审核评论失败", e); // 使用 RuntimeException 替代自定义异常
        }
    }

    // 统一的 DTO 到 BO 转换方法
    private CommentBO convertToBO(CommentDTO commentDTO) {
        CommentBO commentBO = new CommentBO();
        // 手动设置每个字段，确保转换过程的完整性
        commentBO.setCommentId(commentDTO.getCommentId());
        commentBO.setUserId(commentDTO.getUserId());
        commentBO.setUserName(commentDTO.getUserName());
        commentBO.setProductId(commentDTO.getProductId());
        commentBO.setProductName(commentDTO.getProductName());
        commentBO.setRating(commentDTO.getRating());
        commentBO.setContent(commentDTO.getContent());
        // ... 添加其他字段的转换 ...
        return commentBO;
    }

    public void someServiceMethod() {
        try {
            // 一些业务逻辑
        } catch (Exception e) {
            // 假设我们定义了一个错误消息
            String userMessage = "发生了一个错误";
            throw new RuntimeException(userMessage, e); // 使用 RuntimeException 替代自定义异常
        }
    }
}
