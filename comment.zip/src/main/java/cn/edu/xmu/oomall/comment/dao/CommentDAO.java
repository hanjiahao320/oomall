package cn.edu.xmu.oomall.comment.dao;

import cn.edu.xmu.oomall.comment.dao.bo.CommentBO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Param;
import cn.edu.xmu.oomall.comment.controller.vo.PageVo;

import java.util.List;

@Mapper
public interface CommentDAO {

    // 插入评论
    @Insert("INSERT INTO comments (user_id, product_id, rating, content, created_at) " +
            "VALUES (#{userId}, #{productId}, #{rating}, #{content}, NOW())")
    void insertComment(CommentBO commentBO);

    // 根据商品ID获取评论列表
    @Select("SELECT * FROM comments WHERE product_id = #{productId} LIMIT #{pageVo.limit} OFFSET #{pageVo.offset}")
    List<CommentBO> getCommentsByProductId(@Param("pageVo") PageVo pageVo, @Param("productId") Long productId);

    // 更新评论
    @Update("UPDATE comments SET rating = #{rating}, content = #{content}, updated_at = NOW() WHERE id = #{id}")
    void updateComment(CommentBO commentBO);

    // 删除评论
    @Delete("DELETE FROM comments WHERE id = #{commentId}")
    void deleteComment(@Param("commentId") Long commentId);

    // 回复评论
    @Insert("INSERT INTO comments (user_id, product_id, rating, content, reply_to, created_at) " +
            "VALUES (#{userId}, #{productId}, #{rating}, #{content}, #{replyTo}, NOW())")
    void replyToComment(CommentBO commentBO);

    // 审核评论
    @Update("UPDATE comments SET status = #{status}, audited_at = NOW() WHERE id = #{id}")
    void auditComment(@Param("id") Long id, @Param("status") Integer status);
}