package cn.edu.xmu.oomall.comment.dao.bo;

import cn.edu.xmu.oomall.comment.dao.CommentDAO;
import cn.edu.xmu.oomall.comment.controller.vo.PageVo;
import java.util.List;

public class CommentBO {

    private Long userId;
    private Long productId;
    private Long commentId;
    private Integer rating;     //评分
    private String content;
    private String userName;
    private String productName;

    private CommentDAO commentDAO;


    // Getters and Setters
    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public void setUserName(String userName) {this.userName = userName; }

    public void setCommentId(long commentId) {this.commentId = commentId;}

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public void setProductName(String productName) {this.productName = productName;}

    public Integer getRating() {
        return rating;
    }

    public void setRating(Integer rating) {
        this.rating = rating;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public long getCommentId() {
        return 0;
    }

    public String getUserName() {
        return null;
    }

    public String getProductName() {
        return null;
    }

    //在dao层做CRUD时，本应该做检查判断 这里并未详细展开；
    //下面的方法也是；
    public void createComment(CommentBO commentBO){
        commentDAO.insertComment(commentBO);
    }

    public void addComment(CommentBO commentBO) {
        commentDAO.insertComment(commentBO);
    }

    public List<CommentBO> getComments(PageVo pageVo,long productId) {
        return commentDAO.getCommentsByProductId(pageVo, productId);
    }

    public void updateComment(CommentBO commentBO) {
        commentDAO.updateComment(commentBO);
    }

    public void deleteComment(Long commentId) {
        commentDAO.deleteComment(commentId);
    }

    public void replyToComment(CommentBO commentBO) {
        commentDAO.replyToComment(commentBO);
    }

    public void auditComment(Long id, Integer status) {
        commentDAO.auditComment(id, status);
    }
}
