package cn.edu.xmu.oomall.comment.dao.bo;

public class CommentBO {

    private Long userId;
    private Long productId;
    private Long commentId;
    private Integer rating;     //评分
    private String content;
    private String userName;
    private String productName;

    // Getters and Setters
    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public void setUserName(String userName) {this.userName = userName; }

    public void setCommentId(long commentId) {this.commentId = commentId;}

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public void setProductName(String productName) {this.productName = productName;}

    public Integer getRating() {
        return rating;
    }

    public void setRating(Integer rating) {
        this.rating = rating;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public long getCommentId() {
        return 0;
    }

    public String getUserName() {
        return null;
    }

    public String getProductName() {
        return null;
    }
}
