package cn.edu.xmu.oomall.comment.controller;

import cn.edu.xmu.javaee.core.model.ReturnObject;
import cn.edu.xmu.oomall.comment.controller.vo.CommentVo;
import cn.edu.xmu.oomall.comment.controller.dto.CommentDTO;
import cn.edu.xmu.oomall.comment.service.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.validation.annotation.Validated;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;
import cn.edu.xmu.oomall.comment.controller.vo.PageVo;

import javax.validation.Valid;
import java.util.List;

/**
 * 评论管理控制器
 */
@RestController
@RequestMapping("/comments")
@Validated
public class CommentController {
    @Autowired
    private CommentService commentService;
    // 假设我们有一个评论Service，负责具体的业务操作
    /**
     * 添加评论
     *
     * @param commentDTO 评论信息
     * @return 返回操作结果
     */
    @PostMapping("/add")
    @Transactional
    public ResponseEntity<?> addComment(@Valid @RequestBody CommentDTO commentDTO) {
        try {
            commentService.addComment(commentDTO);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "评论添加失败", e);
        }
    }

    /**
     * 追评
     *
     * @param commentDTO 评论信息
     * @return 返回操作结果
     */
    @PostMapping("/followUp")
    @Transactional
    public ResponseEntity<?> followUpComment(@Valid @RequestBody CommentDTO commentDTO) {
        try {
            commentService.additionalComment(commentDTO);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "追评失败", e);
        }
    }

    /**
     * 删除评论
     *
     * @param commentId 评论ID
     * @return 返回操作结果
     */
    @DeleteMapping("/delete/{commentId}")
    @Transactional
    public ResponseEntity<?> deleteComment(@PathVariable Long commentId) {
        try {
            commentService.deleteComment(commentId);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "删除评论失败", e);
        }
    }

    /**
     * 商家回复评论
     *
     * @param commentDTO 评论信息（包含回复内容）
     * @return 返回操作结果
     */
    @PostMapping("/reply")
    @Transactional
    public ResponseEntity<?> replyToComment(@Valid @RequestBody CommentDTO commentDTO) {
        try {
            commentService.replyToComment(commentDTO);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "回复评论失败", e);
        }
    }

    /**
     * 平台审核评论
     *
     * @param commentId 评论ID
     * @param status 审核状态
     * @return 返回操作结果
     */
    @PutMapping("/audit/{commentId}")
    @Transactional
    public ResponseEntity<?> auditComment(@PathVariable Long commentId, @RequestParam Integer status) {
        try {
            commentService.auditComment(commentId, status);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "审核评论失败", e);
        }
    }

    /**
     * 获取评论列表
     *
     * @param pageVo 分页参数
     * @param productId 商品ID
     * @return 评论列表
     */
    @GetMapping("/list")
    public ResponseEntity<List<CommentVo>> getComments(PageVo pageVo, @RequestParam Long productId) {
        try {
            List<CommentVo> comments = commentService.getCommentsByProductId(pageVo, productId);
            return ResponseEntity.ok(comments);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "获取评论失败", e);
        }
    }
}