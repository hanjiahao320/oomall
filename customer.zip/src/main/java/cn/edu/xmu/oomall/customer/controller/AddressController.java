package cn.edu.xmu.oomall.customer.controller;

import cn.edu.xmu.oomall.customer.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import cn.edu.xmu.oomall.customer.controller.dto.AddressDTO;
import cn.edu.xmu.oomall.customer.service.AddressService;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import cn.edu.xmu.oomall.customer.controller.vo.AddressVO;
import javax.validation.Valid;


import java.util.List;

@RestController
@RequestMapping("/addresses")
public class AddressController {

    private  AddressService addressService;  // 假设你有一个 AddressService 来处理业务逻辑

    // 构造函数注入 AddressService
    public AddressController(AddressService addressService) {
        this.addressService = addressService;
    }

    // 顾客添加地址
    @PostMapping("/add")
    public ResponseEntity<String> addAddress(@Valid @RequestBody AddressDTO addressDTO) {
        addressService.addAddress(addressDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body("Address added successfully");
    }

    // 顾客删除地址
    @DeleteMapping("/delete/{addressId}")
    public ResponseEntity<String> deleteAddress(@PathVariable Long addressId) {
        addressService.deleteAddress(addressId);
        return ResponseEntity.status(HttpStatus.OK).body("Address deleted successfully");
    }

    // 顾客查看地址列表
    @GetMapping("/view/{customerId}")
    public ResponseEntity<List<AddressVO>> viewAddresses(@PathVariable Long customerId) {
        List<AddressVO> addresses = addressService.viewAddresses(customerId);
        return ResponseEntity.status(HttpStatus.OK).body(addresses);
    }

    // 顾客更新地址
    @PutMapping("/update/{addressId}")
    public ResponseEntity<String> updateAddress(@PathVariable Long addressId, @Valid @RequestBody AddressDTO addressDTO) {
        addressService.updateAddress(addressId, addressDTO);
        return ResponseEntity.status(HttpStatus.OK).body("Address updated successfully");
    }
}

