package cn.edu.xmu.oomall.customer.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import cn.edu.xmu.oomall.customer.dao.AddressRepository;
import cn.edu.xmu.oomall.customer.controller.dto.AddressDTO;
import cn.edu.xmu.oomall.customer.dao.bo.Address;
import cn.edu.xmu.oomall.customer.controller.vo.AddressVO;
import java.util.List;
import java.util.stream.Collectors;


@Service
public class AddressService {

    private final AddressRepository addressRepository;

    // 构造函数注入 AddressRepository
    public AddressService(AddressRepository addressRepository) {
        this.addressRepository = addressRepository;
    }

    // 添加地址
    public void addAddress(AddressDTO addressDTO) {
        Address address = new Address();
        address.setCustomerId(addressDTO.getCustomerId());
        address.setStreet(addressDTO.getStreet());
        address.setCity(addressDTO.getCity());
        address.setPostalCode(addressDTO.getPostalCode());
        address.setCountry(addressDTO.getCountry());
        addressRepository.save(address);  // 保存地址到数据库
    }

    // 删除地址
    public void deleteAddress(Long addressId) {
        addressRepository.deleteById(addressId);  // 删除地址
    }

    // 查看地址
    public List<AddressVO> viewAddresses(Long customerId) {
        List<Address> addresses = addressRepository.findByCustomerId(customerId);  // 查询该顾客的所有地址
        return addresses.stream()
                .map(this::convertToAddressVO)  // 将 Address 实体转换为 AddressVO
                .collect(Collectors.toList());
    }

    // 更新地址
    public void updateAddress(Long addressId, AddressDTO addressDTO) {
        // 查找现有地址
        Address address = addressRepository.findById(addressId)
                .orElseThrow(() -> new RuntimeException("Address not found"));

        // 更新地址信息
        address.setStreet(addressDTO.getStreet());
        address.setCity(addressDTO.getCity());
        address.setPostalCode(addressDTO.getZipCode());  // 将 zipCode 映射到 Address 的 postalCode
        // 保存更新后的地址
        addressRepository.save(address);  // 更新地址
    }


    // 将 Address 实体转换为 AddressVO
    private AddressVO convertToAddressVO(Address address) {
        AddressVO addressVO = new AddressVO();
        addressVO.setId(address.getId());
        addressVO.setStreet(address.getStreet());
        addressVO.setCity(address.getCity());
        addressVO.setPostalCode(address.getPostalCode());
        addressVO.setCountry(address.getCountry());
        // 设置其他字段
        return addressVO;
    }
}
