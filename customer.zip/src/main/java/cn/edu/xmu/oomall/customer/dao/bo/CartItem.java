package cn.edu.xmu.oomall.customer.dao.bo;

public class CartItem {

    private Long id;  // 购物项的唯一标识符

    private cn.edu.xmu.oomall.customer.dao.bo.Customer customer;  // 顾客

    private cn.edu.xmu.oomall.customer.dao.bo.Product product;  // 商品

    private int quantity;  // 商品数量

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setProductId(Long id) {
        this.id = id;
    }

    public void setCustomerId(Long id) {
        this.id = id;
    }

    public cn.edu.xmu.oomall.customer.dao.bo.Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public cn.edu.xmu.oomall.customer.dao.bo.Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public long getProductId(){
        return product.getId();
    }

    // 可以根据需要添加更多方法或字段
}
