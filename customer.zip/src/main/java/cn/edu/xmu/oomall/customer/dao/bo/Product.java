package cn.edu.xmu.oomall.customer.dao.bo;

public class Product {

    private Long id;  // 商品的唯一标识符
    private String name;  // 商品名称
    private double price;  // 商品价格
    private String description;  // 商品描述
    private String imageUrl;  // 商品图片的 URL

    // 构造方法
    public Product() {
    }

    public Product(Long id, String name, double price, String description, String imageUrl) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.description = description;
        this.imageUrl = imageUrl;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    // 可以根据需要添加其他功能，比如自定义的 toString 方法、equals 和 hashCode 方法
}
