package cn.edu.xmu.oomall.customer.controller;

import cn.edu.xmu.oomall.customer.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import cn.edu.xmu.oomall.customer.dao.bo.CartItem;
import java.util.List;

@RestController
@RequestMapping("/cart")
public class CartController {

    @Autowired
    private CartService cartService;

    //加入购物车
    @PostMapping("/add/{customerId}/{productId}")
    public String addToCart(@PathVariable Long customerId, @PathVariable Long productId) {
        cartService.addToCart(customerId, productId);
        return "Product added to cart successfully!";
    }

    //删除购物车
    @DeleteMapping("/remove/{customerId}/{productId}")
    public String removeFromCart(@PathVariable Long customerId, @PathVariable Long productId) {
        cartService.removeFromCart(customerId, productId);
        return "Product removed from cart successfully!";
    }

    // 获取购物车商品列表
    @GetMapping("/items/{customerId}")
    public List<CartItem> getCartItems(@PathVariable Long customerId) {
        return cartService.getCartItems(customerId);
    }
}
