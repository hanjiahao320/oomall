package cn.edu.xmu.oomall.customer.controller.vo;

public class CouponVO {

    private Long id;
    private String title;
    private double discount;
    private int availableStock;

    // 默认构造方法
    public CouponVO() {
    }

    // 带参构造方法
    public CouponVO(Long id, String title, double discount, int availableStock) {
        this.id = id;
        this.title = title;
        this.discount = discount;
        this.availableStock = availableStock;
    }

    // Getter 和 Setter 方法
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }

    public int getAvailableStock() {
        return availableStock;
    }

    public void setAvailableStock(int availableStock) {
        this.availableStock = availableStock;
    }

    // 重写 toString() 方法
    @Override
    public String toString() {
        return "CouponVO{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", discount=" + discount +
                ", availableStock=" + availableStock +
                '}';
    }
}
