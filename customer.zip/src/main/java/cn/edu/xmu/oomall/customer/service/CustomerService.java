package cn.edu.xmu.oomall.customer.service;

import cn.edu.xmu.javaee.core.exception.BusinessException;
import cn.edu.xmu.oomall.customer.controller.dto.AddressDTO;
import cn.edu.xmu.oomall.customer.controller.dto.CartItemDTO;
import cn.edu.xmu.oomall.customer.controller.vo.AddressVO;
import cn.edu.xmu.oomall.customer.controller.vo.CartItemVO;
import cn.edu.xmu.oomall.customer.dao.CustomerRepository;
import cn.edu.xmu.oomall.customer.dao.AddressRepository;
import cn.edu.xmu.oomall.customer.dao.CartItemRepository;
import cn.edu.xmu.oomall.customer.dao.bo.Address;
import cn.edu.xmu.oomall.customer.dao.bo.CartItem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CustomerService {

    @Autowired
    private AddressRepository addressRepository;  // 使用 JPA Repository 处理地址相关数据库操作

    @Autowired
    private CartItemRepository cartItemRepository;  // 使用 JPA Repository 处理购物车项数据库操作

    // 添加地址
    public void addAddress(AddressDTO addressDTO) throws BusinessException {

        Address address = new Address();
        // 将 DTO 转换为实体对象
        address.setStreet(addressDTO.getStreet());
        address.setCity(addressDTO.getCity());
        address.setCustomerId(addressDTO.getCustomerId());  // 假设传入的 DTO 中有 customerId

        // 保存地址到数据库
        addressRepository.save(address);
    }

    // 删除地址
    public void deleteAddress(Long addressId) throws BusinessException {

        addressRepository.deleteById(addressId);
    }

    // 查看地址
    public List<AddressVO> viewAddresses(Long customerId) {
        // 查询该客户的所有地址
        List<Address> addresses = addressRepository.findAddressesByCustomerId(customerId);
        // 转换为 VO 对象
        return addresses.stream().map(this::convertToVO).collect(Collectors.toList());
    }

    // 领取优惠券（此处可以扩展业务逻辑）
    public void claimCoupon(Long customerId, Long couponId) {
        // 业务逻辑，比如检查优惠券是否有效，是否已被领取等
        // 此处假设没有具体实现，需要根据需求补充
    }

    // 将商品添加到购物车
    public void addToCart(CartItemDTO cartItemDTO) throws BusinessException {

        CartItem cartItem = new CartItem();
        // 转换 DTO 到实体
        cartItem.setProductId(cartItemDTO.getProductId());
        cartItem.setQuantity(cartItemDTO.getQuantity());
        cartItem.setCustomerId(cartItemDTO.getCustomerId());  // 假设 DTO 包含 customerId

        // 保存到购物车数据库
        cartItemRepository.save(cartItem);
    }

    // 从购物车删除商品
    public void removeFromCart(Long cartItemId) throws BusinessException {

        cartItemRepository.deleteById(cartItemId);
    }

    // 查看购物车
    public List<CartItemVO> viewCart(Long customerId) {
        // 查询该客户的购物车项
        List<CartItem> cartItems = cartItemRepository.findCartItemsByCustomerId(customerId);
        // 转换为 VO 对象
        return cartItems.stream().map(this::convertToCartItemVO).collect(Collectors.toList());
    }

    // 将 Address 实体转换为 AddressVO
    private AddressVO convertToVO(Address address) {
        AddressVO vo = new AddressVO();
        vo.setStreet(address.getStreet());
        vo.setCity(address.getCity());
        // 其他转换逻辑
        return vo;
    }

    // 将 CartItem 实体转换为 CartItemVO
    private CartItemVO convertToCartItemVO(CartItem cartItem) {
        CartItemVO vo = new CartItemVO();
        vo.setProductId(cartItem.getProductId());
        vo.setQuantity(cartItem.getQuantity());
        // 其他转换逻辑
        return vo;
    }
}

