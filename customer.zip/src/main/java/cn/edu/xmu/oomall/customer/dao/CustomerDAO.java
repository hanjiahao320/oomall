package cn.edu.xmu.oomall.customer.dao;

import cn.edu.xmu.oomall.customer.dao.bo.Customer;
import org.springframework.stereotype.Repository;

@Repository
public class CustomerDAO {

    public void addCustomer(Customer customer) {
        // 假设直接操作数据库
        System.out.println("Adding customer: " + customer);
    }

    public void deleteCustomer(Long id) {
        // 假设直接删除
        System.out.println("Deleting customer with id: " + id);
    }

    public Customer getCustomer(Long id) {
        // 假设返回一个虚拟的顾客
        return new Customer(id, "John Doe", "john.doe@example.com","148xxxxxxx","abc");
    }
}
