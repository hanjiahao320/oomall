package cn.edu.xmu.oomall.customer.controller.dto;

public class CartItemDTO {
    private Long productId;
    private int quantity;
    private Long customerId;

    // Default constructor
    public CartItemDTO() {}

    // Constructor with fields
    public CartItemDTO(Long productId, int quantity, Long customerId) {
        this.productId = productId;
        this.quantity = quantity;
        this.customerId = customerId;
    }

    // Getters and setters
    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }
}
