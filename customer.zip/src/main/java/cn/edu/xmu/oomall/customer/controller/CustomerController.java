package cn.edu.xmu.oomall.customer.controller;

import cn.edu.xmu.oomall.customer.service.CustomerService;

import cn.edu.xmu.oomall.customer.controller.dto.AddressDTO;
import cn.edu.xmu.oomall.customer.controller.vo.AddressVO;
import cn.edu.xmu.oomall.customer.controller.dto.CartItemDTO;
import cn.edu.xmu.oomall.customer.controller.vo.CartItemVO;
import org.springframework.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import org.springframework.http.ResponseEntity;
import javax.validation.Valid;


@RestController
@RequestMapping("/customers")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    // 顾客添加地址
    @PostMapping("/addAddress")
    public ResponseEntity<String> addAddress(@Valid @RequestBody AddressDTO addressDTO) {
        customerService.addAddress(addressDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body("Address added successfully");
    }

    // 顾客删除地址
    @DeleteMapping("/deleteAddress/{addressId}")
    public ResponseEntity<String> deleteAddress(@PathVariable Long addressId) {
        customerService.deleteAddress(addressId);
        return ResponseEntity.status(HttpStatus.OK).body("Address deleted successfully");
    }

    // 顾客查看地址
    @GetMapping("/viewAddresses/{customerId}")
    public ResponseEntity<List<AddressVO>> viewAddresses(@PathVariable Long customerId) {
        List<AddressVO> addresses = customerService.viewAddresses(customerId);
        return ResponseEntity.status(HttpStatus.OK).body(addresses);
    }

    // 顾客领取优惠券
    @PostMapping("/claimCoupon/{couponId}")
    public ResponseEntity<String> claimCoupon(@PathVariable Long couponId, @RequestParam Long customerId) {
        customerService.claimCoupon(customerId, couponId);
        return ResponseEntity.status(HttpStatus.OK).body("Coupon claimed successfully");
    }
    // 获取所有可用的优惠券
    @GetMapping("/availableCoupons")
    public ResponseEntity<String> getAvailableCoupons() {
        customerService.getAvailableCoupons();
        return ResponseEntity.status(HttpStatus.OK).body("All coupons aquired successfully");
    }

    // 查看用户已领取的优惠券
    @GetMapping("/userCoupons/{customerId}")
    public ResponseEntity<String> getUserCoupons(@PathVariable Long customerId) {
        customerService.getUserCoupons(customerId);
        return ResponseEntity.status(HttpStatus.OK).body("All coupons listed successfully");
    }

    // 顾客将商品加入购物车
    @PostMapping("/addToCart")
    public ResponseEntity<String> addToCart(@Valid @RequestBody CartItemDTO cartItemDTO) {
        customerService.addToCart(cartItemDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body("Item added to cart");
    }

    // 顾客删除购物车商品
    @DeleteMapping("/removeFromCart/{cartItemId}")
    public ResponseEntity<String> removeFromCart(@PathVariable Long cartItemId) {
        customerService.removeFromCart(cartItemId);
        return ResponseEntity.status(HttpStatus.OK).body("Item removed from cart");
    }

    // 顾客查看购物车
    @GetMapping("/viewCart/{customerId}")
    public ResponseEntity<List<CartItemVO>> viewCart(@PathVariable Long customerId) {
        List<CartItemVO> cartItems = customerService.viewCart(customerId);
        return ResponseEntity.status(HttpStatus.OK).body(cartItems);
    }
}
