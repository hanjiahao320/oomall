package cn.edu.xmu.oomall.customer.service;

import cn.edu.xmu.oomall.customer.dao.CartDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import cn.edu.xmu.oomall.customer.dao.bo.CartItem;
import java.util.List;

@Service
public class CartService {

    @Autowired
    private CartDAO cartDAO;

    private CartItem cartItem;

    public void addToCart(Long customerId, Long productId) {
        CartItem cartItem = new CartItem();
        cartItem.addToCart(customerId, productId);
    }

    public void removeFromCart(Long customerId, Long productId) {
        CartItem cartItem = new CartItem();
        cartItem.removeFromCart(customerId, productId);
    }

    // 获取购物车商品列表
    public List<CartItem> getCartItems(Long customerId) {
        return cartDAO.getCartItemsByCustomerId(customerId);
    }
}
