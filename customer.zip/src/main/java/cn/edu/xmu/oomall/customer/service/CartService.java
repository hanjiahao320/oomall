package cn.edu.xmu.oomall.customer.service;

import cn.edu.xmu.oomall.customer.dao.CartDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CartService {

    @Autowired
    private CartDAO cartDAO;

    public void addToCart(Long customerId, Long productId) {
        cartDAO.addToCart(customerId, productId);
    }

    public void removeFromCart(Long customerId, Long productId) {
        cartDAO.removeFromCart(customerId, productId);
    }
}
