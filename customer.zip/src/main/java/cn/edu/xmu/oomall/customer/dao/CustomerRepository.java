package cn.edu.xmu.oomall.customer.dao;

import cn.edu.xmu.oomall.customer.dao.bo.Address;
import cn.edu.xmu.oomall.customer.dao.bo.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;


public interface CustomerRepository extends JpaRepository<Customer, Long> {
    // 可以根据客户ID查询地址
    List<Address> findAddressesByCustomerId(Long customerId);

    // 如果需要根据顾客ID查询顾客，可以使用 findById 方法
    Optional<Customer> findById(Long customerId);  // 注意：findById 返回 Optional
}
