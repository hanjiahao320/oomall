package cn.edu.xmu.oomall.customer.dao.bo;

import java.time.LocalDate;  // 导入 LocalDate 类型
import java.util.List;

public class Coupon {

    private Long id;

    private String title;  // 优惠券标题
    private String description;  // 优惠券描述
    private double discount;  // 优惠金额或折扣
    private int availableStock;  // 可用库存，数量限制
    private LocalDate validFrom;  // 有效开始时间
    private LocalDate validUntil;  // 有效截止时间

    // 构造方法
    public Coupon() {
    }

    public Coupon(Long id, String title, String description, double discount, int availableStock, LocalDate validFrom, LocalDate validUntil) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.discount = discount;
        this.availableStock = availableStock;
        this.validFrom = validFrom;
        this.validUntil = validUntil;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }

    public int getAvailableStock() {
        return availableStock;
    }

    public void setAvailableStock(int availableStock) {
        this.availableStock = availableStock;
    }

    public LocalDate getValidFrom() {
        return validFrom;
    }

    public void setValidFrom(LocalDate validFrom) {
        this.validFrom = validFrom;
    }

    public LocalDate getValidUntil() {
        return validUntil;
    }

    public void setValidUntil(LocalDate validUntil) {
        this.validUntil = validUntil;
    }

    // toString 方法，便于打印和调试
    @Override
    public String toString() {
        return "Coupon{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", description='" + description + '\'' +
                ", discount=" + discount +
                ", availableStock=" + availableStock +
                ", validFrom=" + validFrom +
                ", validUntil=" + validUntil +
                '}';
    }

    // hashCode 和 equals 方法（可以根据需要自行实现）
}
