package cn.edu.xmu.oomall.customer.controller.dto;

public class AddressDTO {

    private String street;
    private String city;
    private String zipCode;  // 假设原来是 zipCode
    private String postalCode;  // 补充的 postalCode
    private String country;  // 补充的 country
    private Long customerId;

    // Getter 和 Setter 方法
    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPostalCode() {
        return postalCode;  // 添加的 getPostalCode 方法
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;  // 添加的 setPostalCode 方法
    }

    public String getCountry() {
        return country;  // 添加的 getCountry 方法
    }

    public void setCountry(String country) {
        this.country = country;  // 添加的 setCountry 方法
    }

    public String getZipCode() {
        return zipCode;  // 原来的 zipCode
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;  // 原来的 zipCode
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }
}
