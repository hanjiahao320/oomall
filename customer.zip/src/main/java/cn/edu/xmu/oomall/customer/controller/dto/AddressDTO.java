package cn.edu.xmu.oomall.customer.controller.dto;

public class AddressDTO {
    private String street;
    private String city;
    private String zipCode;
    private Long customerId;

    // Default constructor
    public AddressDTO() {}

    // Constructor with fields
    public AddressDTO(String street, String city, String zipCode, Long customerId) {
        this.street = street;
        this.city = city;
        this.zipCode = zipCode;
        this.customerId = customerId;
    }

    // Getters and setters
    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }
}
