package cn.edu.xmu.oomall.customer.controller.vo;

public class AddressVO {
    private String street;
    private String city;
    private String zipCode;  // 添加邮政编码

    // Getters 和 Setters
    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }
}
