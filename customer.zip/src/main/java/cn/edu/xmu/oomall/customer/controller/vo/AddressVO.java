package cn.edu.xmu.oomall.customer.controller.vo;

public class AddressVO {

    private Long id;           // 地址 ID
    private String street;     // 街道
    private String city;       // 城市
    private String postalCode; // 邮政编码
    private String country;    // 国家

    // 默认构造器
    public AddressVO() {
    }

    // 带参构造器
    public AddressVO(Long id, String street, String city, String postalCode, String country) {
        this.id = id;
        this.street = street;
        this.city = city;
        this.postalCode = postalCode;
        this.country = country;
    }

    // Getter 和 Setter 方法

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    // 重写 toString 方法，方便调试输出
    @Override
    public String toString() {
        return "AddressVO{" +
                "id=" + id +
                ", street='" + street + '\'' +
                ", city='" + city + '\'' +
                ", postalCode='" + postalCode + '\'' +
                ", country='" + country + '\'' +
                '}';
    }
}
