package cn.edu.xmu.oomall.customer.dao;

import cn.edu.xmu.oomall.customer.dao.bo.Coupon;
import cn.edu.xmu.oomall.customer.dao.bo.CouponHistory;
import cn.edu.xmu.oomall.customer.service.CouponService;
import cn.edu.xmu.oomall.customer.controller.vo.CouponVO;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CouponRepository extends JpaRepository<Coupon, Long> {

    // 查询库存大于指定值的优惠券
    List<Coupon> findByAvailableStockGreaterThan(int stock);

    // 查询用户领取的所有优惠券记录
    List<CouponHistory> findCouponsByCustomerId(Long customerId);

    // 查询所有有效的优惠券
    List<Coupon> findAllByIsValidTrue();

    // 查询指定客户所有有效的优惠券
    List<Coupon> findByCustomerIdAndIsValidTrue(Long customerId);

    //领取优惠卷
    void claimCoupon(Long customerId, Long couponId);
}
