package cn.edu.xmu.oomall.customer.dao;

import cn.edu.xmu.oomall.customer.dao.bo.Coupon;
import cn.edu.xmu.oomall.customer.dao.bo.CouponHistory;
import cn.edu.xmu.oomall.customer.service.CouponService;
import cn.edu.xmu.oomall.customer.controller.vo.CouponVO;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CouponRepository extends JpaRepository<Coupon, Long> {

    List<Coupon> findByAvailableStockGreaterThan(int stock);

    List<CouponHistory> findCouponsByCustomerId(Long customerId);  // 查询用户领取的优惠券记录
}
