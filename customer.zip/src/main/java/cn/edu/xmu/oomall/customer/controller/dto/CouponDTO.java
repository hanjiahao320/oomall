package cn.edu.xmu.oomall.customer.controller.dto;
import cn.edu.xmu.oomall.customer.dao.bo.Coupon;
import java.time.LocalDate;

// 根据服务层的Coupon相关业务逻辑，调整后的CouponDTO，用于在不同层之间传递优惠券数据
public class CouponDTO {
    private Long couponId;
    private String title;
    private double discount;
    private int availableStock;
    private LocalDate validUntil;

    // Default constructor
    public CouponDTO() {}

    // 构造函数，从Coupon对象转换过来，方便进行对象转换
    public CouponDTO(Coupon coupon) {
        this.couponId = coupon.getId();
        this.title = coupon.getTitle();
        this.discount = coupon.getDiscount();
        this.availableStock = coupon.getAvailableStock();
        this.validUntil = coupon.getValidUntil();
    }

    // Getters and setters
    public Long getCouponId() {
        return couponId;
    }

    public void setCouponId(Long couponId) {
        this.couponId = couponId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }

    public int getAvailableStock() {
        return availableStock;
    }

    public void setAvailableStock(int availableStock) {
        this.availableStock = availableStock;
    }

    public LocalDate getValidUntil() {
        return validUntil;
    }

    public void setValidUntil(LocalDate validUntil) {
        this.validUntil = validUntil;
    }
}