package cn.edu.xmu.oomall.customer.controller.vo;

public class CartItemVO {
    private Long productId;   // 商品 ID
    private String productName; // 商品名称
    private int quantity;     // 商品数量
    private double price;      // 商品价格

    // Getters 和 Setters
    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}
