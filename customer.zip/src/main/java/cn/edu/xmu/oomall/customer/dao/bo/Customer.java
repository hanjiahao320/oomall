package cn.edu.xmu.oomall.customer.dao.bo;

import java.util.List;

public class Customer {

    private Long id;  // 顾客ID
    private String name;  // 顾客姓名
    private String email;  // 顾客邮箱
    private String phone;  // 顾客电话
    private String address;  // 顾客地址
    private List<cn.edu.xmu.oomall.customer.dao.bo.CartItem> cartItems;  // 顾客的购物车商品
    private List<cn.edu.xmu.oomall.customer.dao.bo.CouponHistory> couponHistories;  // 顾客的优惠券领取记录

    // 构造方法
    public Customer() {}

    public Customer(long id, String name, String email, String phone, String address) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.address = address;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public List<cn.edu.xmu.oomall.customer.dao.bo.CartItem> getCartItems() {
        return cartItems;
    }

    public void setCartItems(List<CartItem> cartItems) {
        this.cartItems = cartItems;
    }

    public List<cn.edu.xmu.oomall.customer.dao.bo.CouponHistory> getCouponHistories() {
        return couponHistories;
    }

    public void setCouponHistories(List<CouponHistory> couponHistories) {
        this.couponHistories = couponHistories;
    }
}
