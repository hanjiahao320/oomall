package cn.edu.xmu.oomall.customer.dao;

import org.springframework.stereotype.Repository;

@Repository
public class CartDAO {

    public void addToCart(Long customerId, Long productId) {
        System.out.println("Adding product " + productId + " to customer " + customerId + "'s cart");
    }

    public void removeFromCart(Long customerId, Long productId) {
        System.out.println("Removing product " + productId + " from customer " + customerId + "'s cart");
    }
}
