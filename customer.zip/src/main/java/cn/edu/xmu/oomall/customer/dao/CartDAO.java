package cn.edu.xmu.oomall.customer.dao;

import org.springframework.stereotype.Repository;
import org.springframework.beans.factory.annotation.Autowired;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import java.util.List;
import cn.edu.xmu.oomall.customer.dao.bo.CartItem;

@Repository
public class CartDAO {

    @Autowired
    private EntityManager entityManager;

    // 添加商品到购物车
    public void addToCart(Long customerId, Long productId) {
        // 具体数据库操作，假设有Cart实体类
        String sql = "INSERT INTO Cart (customer_id, product_id) VALUES (:customerId, :productId)";
        Query query = entityManager.createNativeQuery(sql);
        query.executeUpdate();
    }

    // 从购物车移除商品
    public void removeFromCart(Long customerId, Long productId) {
        // 具体数据库操作，假设有Cart实体类
        String sql = "DELETE FROM Cart WHERE customer_id = :customerId AND product_id = :productId";
        Query query = entityManager.createNativeQuery(sql);
        query.executeUpdate();
    }

    // 根据用户ID获取购物车商品列表
    public List<CartItem> getCartItemsByCustomerId(Long customerId) {
        // 查询购物车商品列表，假设CartItem为查询返回的实体类
        String sql = "SELECT * FROM Cart WHERE customer_id = :customerId";
        Query query = entityManager.createNativeQuery(sql, CartItem.class);
        return query.getResultList();
    }
}
