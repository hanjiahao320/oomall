package cn.edu.xmu.oomall.customer.dao;

import cn.edu.xmu.oomall.customer.dao.bo.Coupon;
import cn.edu.xmu.oomall.customer.dao.bo.CouponHistory;
import cn.edu.xmu.oomall.customer.service.CouponService;
import cn.edu.xmu.oomall.customer.controller.vo.CouponVO;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;


public interface CouponHistoryRepository extends JpaRepository<CouponHistory, Long> {

    // 根据用户 ID 获取该用户领取的优惠券历史
    List<CouponHistory> findByCustomerId(Long customerId);
}