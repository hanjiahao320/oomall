package cn.edu.xmu.oomall.customer.controller;

import cn.edu.xmu.oomall.customer.service.CartService;
import cn.edu.xmu.oomall.customer.service.CouponService;
import cn.edu.xmu.oomall.customer.controller.vo.CouponVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;
import javax.validation.Valid;
import org.springframework.http.ResponseEntity;


@RestController
@RequestMapping("/coupon")
public class CouponController {

    @Autowired
    private CouponService couponService;

    // 顾客领取优惠券
    @PostMapping("/claimCoupon/{couponId}")
    public ResponseEntity<String> claimCoupon(@PathVariable Long couponId, @RequestParam Long customerId) {
        couponService.claimCoupon(customerId, couponId);
        return ResponseEntity.status(HttpStatus.OK).body("Coupon claimed successfully");
    }

    // 获取所有可用的优惠券
    @GetMapping("/availableCoupons")
    public ResponseEntity<List<CouponVO>> getAvailableCoupons() {
        List<CouponVO> coupons = couponService.getAvailableCoupons();
        return ResponseEntity.status(HttpStatus.OK).body(coupons);
    }

    // 查看用户已领取的优惠券
    @GetMapping("/userCoupons/{customerId}")
    public ResponseEntity<List<CouponVO>> getUserCoupons(@PathVariable Long customerId) {
        List<CouponVO> coupons = couponService.getUserCoupons(customerId);
        return ResponseEntity.status(HttpStatus.OK).body(coupons);
    }
}
