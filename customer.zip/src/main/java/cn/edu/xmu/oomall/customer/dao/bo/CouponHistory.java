package cn.edu.xmu.oomall.customer.dao.bo;

import java.time.LocalDate;  // 导入 LocalDate 类型


public class CouponHistory {

    private Long id;

    private cn.edu.xmu.oomall.customer.dao.bo.Customer customer;  // 用户

    private cn.edu.xmu.oomall.customer.dao.bo.Coupon coupon;  // 优惠券

    private LocalDate claimedDate;  // 领取日期

    // 无参构造方法
    public CouponHistory() {
    }

    // 带参构造方法
    public CouponHistory(Long id, cn.edu.xmu.oomall.customer.dao.bo.Customer customer, cn.edu.xmu.oomall.customer.dao.bo.Coupon coupon, LocalDate claimedDate) {
        this.id = id;
        this.customer = customer;
        this.coupon = coupon;
        this.claimedDate = claimedDate;
    }

    // Getters 和 Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public cn.edu.xmu.oomall.customer.dao.bo.Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public cn.edu.xmu.oomall.customer.dao.bo.Coupon getCoupon() {
        return coupon;
    }

    public void setCoupon(Coupon coupon) {
        this.coupon = coupon;
    }

    public LocalDate getClaimedDate() {
        return claimedDate;
    }

    public void setClaimedDate(LocalDate claimedDate) {
        this.claimedDate = claimedDate;
    }

    // toString 方法，便于打印和调试
    @Override
    public String toString() {
        return "CouponHistory{" +
                "id=" + id +
                ", customer=" + customer +
                ", coupon=" + coupon +
                ", claimedDate=" + claimedDate +
                '}';
    }

    // hashCode 和 equals 方法（可以根据需要自行实现）
}
