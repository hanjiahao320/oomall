package cn.edu.xmu.oomall.customer.dao;

import cn.edu.xmu.oomall.customer.dao.bo.CartItem;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface CartItemRepository extends JpaRepository<CartItem, Long> {

    // 根据顾客ID查询购物车中的商品
    List<CartItem> findCartItemsByCustomerId(Long customerId);

    // 根据顾客ID和商品状态（例如：已选中或未选中）查询购物车商品
    List<CartItem> findByCustomerIdAndStatus(Long customerId, String status);

    // 根据顾客ID和商品类别查询购物车商品
    List<CartItem> findByCustomerIdAndProductCategory(Long customerId, String productCategory);

    // 根据顾客ID和商品ID查询购物车中的特定商品
    Optional<CartItem> findByCustomerIdAndProductId(Long customerId, Long productId);

}
