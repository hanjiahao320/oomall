package cn.edu.xmu.oomall.customer.dao.bo;

public class Address {

    private Long id;  // 地址的唯一标识符
    private Long customerId;  // 关联的客户ID
    private String street;  // 街道
    private String city;    // 城市

    // 其他地址字段，比如省份、邮政编码等

    // Getter 和 Setter 方法
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    // 可以根据需要添加更多字段和方法
}
