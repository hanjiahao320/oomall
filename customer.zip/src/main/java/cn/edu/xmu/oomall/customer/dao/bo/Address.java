package cn.edu.xmu.oomall.customer.dao.bo;

import cn.edu.xmu.oomall.customer.controller.dto.AddressDTO;
import cn.edu.xmu.oomall.customer.dao.AddressRepository;

public class Address {

    private Long id;  // 地址的唯一标识符
    private Long customerId;  // 关联的客户ID
    private String street;  // 街道
    private String city;    // 城市
    private String postalCode; // 邮政编码
    private String country;   // 国家

    // 其他地址字段，比如省份、州等
    private String state; // 省或州

    // 默认构造器
    public Address() {
    }

    // 带参构造器，方便初始化对象
    public Address(Long customerId, String street, String city, String postalCode, String country, String state) {
        this.customerId = customerId;
        this.street = street;
        this.city = city;
        this.postalCode = postalCode;
        this.country = country;
        this.state = state;
    }

    // Getter 和 Setter 方法

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    // 重写 toString 方法，方便调试和查看地址信息
    @Override
    public String toString() {
        return "Address{" +
                "id=" + id +
                ", customerId=" + customerId +
                ", street='" + street + '\'' +
                ", city='" + city + '\'' +
                ", postalCode='" + postalCode + '\'' +
                ", country='" + country + '\'' +
                ", state='" + state + '\'' +
                '}';
    }


}
