package cn.edu.xmu.oomall.customer.service;

import cn.edu.xmu.oomall.customer.dao.CartDAO;
import cn.edu.xmu.oomall.customer.dao.bo.Customer;
import cn.edu.xmu.oomall.customer.dao.bo.Coupon;
import cn.edu.xmu.oomall.customer.dao.bo.CouponHistory;
import cn.edu.xmu.oomall.customer.service.CartService;
import cn.edu.xmu.oomall.customer.service.CouponService;
import cn.edu.xmu.oomall.customer.controller.vo.CouponVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import cn.edu.xmu.oomall.customer.dao.CouponRepository;
import cn.edu.xmu.oomall.customer.dao.CustomerRepository;
import cn.edu.xmu.oomall.customer.dao.CouponHistoryRepository;
import java.util.List;
import java.time.LocalDate;
import java.util.stream.Collectors;


@Service
public class CouponService {

    @Autowired
    private CouponRepository couponRepository;  // JPA Repository

    @Autowired
    private CustomerRepository customerRepository;  // JPA Repository

    @Autowired
    private CouponHistoryRepository couponHistoryRepository; // 用于记录优惠券领取历史的 Repository

    // 领取优惠券
    public void claimCoupon(Long customerId, Long couponId) {
        // 查找优惠券
        Coupon coupon = couponRepository.findById(couponId)
                .orElseThrow(() -> new RuntimeException("Coupon not found"));

        // 查找顾客
        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new RuntimeException("Customer not found"));

        // 领取优惠券的逻辑：检查优惠券是否有库存
        if (coupon.getAvailableStock() > 0) {
            // 减少优惠券库存
            coupon.setAvailableStock(coupon.getAvailableStock() - 1);
            couponRepository.save(coupon);

            // 创建一条优惠券领取记录
            CouponHistory couponHistory = new CouponHistory();
            couponHistory.setCustomer(customer);
            couponHistory.setCoupon(coupon);
            couponHistory.setClaimedDate(LocalDate.now());

            couponHistoryRepository.save(couponHistory);
        } else {
            throw new RuntimeException("Coupon out of stock");
        }
    }

    // 获取所有可用的优惠券
    public List<CouponVO> getAvailableCoupons() {
        List<Coupon> availableCoupons = couponRepository.findByAvailableStockGreaterThan(0);
        return availableCoupons.stream()
                .map(this::convertToVO)
                .collect(Collectors.toList());
    }

    // 获取用户已领取的优惠券
    public List<CouponVO> getUserCoupons(Long customerId) {
        List<CouponHistory> couponHistories = couponHistoryRepository.findByCustomerId(customerId);
        return couponHistories.stream()
                .map(ch -> convertToVO(ch.getCoupon()))
                .collect(Collectors.toList());
    }

    // VO 转换
    private CouponVO convertToVO(Coupon coupon) {
        CouponVO vo = new CouponVO();
        vo.setId(coupon.getId());
        vo.setTitle(coupon.getTitle());
        vo.setDiscount(coupon.getDiscount());
        vo.setAvailableStock(coupon.getAvailableStock());
        return vo;
    }
}
