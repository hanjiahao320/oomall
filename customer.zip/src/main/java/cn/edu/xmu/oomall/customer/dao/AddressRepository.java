package cn.edu.xmu.oomall.customer.dao;

import cn.edu.xmu.oomall.customer.dao.bo.Address;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface AddressRepository extends JpaRepository<Address, Long> {
    // 根据 customerId 查找该客户的所有地址
    List<Address> findAddressesByCustomerId(Long customerId);

    // 其他地址相关的查询方法可以根据需要添加
}
