package cn.edu.xmu.oomall.customer.dao.bo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.within;

class CouponTest {

    private Coupon couponUnderTest;

    @BeforeEach
    void setUp() {
        couponUnderTest = new Coupon(0L, "title", "description", 0.0, 0, LocalDate.of(2020, 1, 1),
                LocalDate.of(2020, 1, 1));
    }

    @Test
    void testIdGetterAndSetter() {
        final Long id = 0L;
        couponUnderTest.setId(id);
        assertThat(couponUnderTest.getId()).isEqualTo(id);
    }

    @Test
    void testTitleGetterAndSetter() {
        final String title = "title";
        couponUnderTest.setTitle(title);
        assertThat(couponUnderTest.getTitle()).isEqualTo(title);
    }

    @Test
    void testDescriptionGetterAndSetter() {
        final String description = "description";
        couponUnderTest.setDescription(description);
        assertThat(couponUnderTest.getDescription()).isEqualTo(description);
    }

    @Test
    void testDiscountGetterAndSetter() {
        final double discount = 0.0;
        couponUnderTest.setDiscount(discount);
        assertThat(couponUnderTest.getDiscount()).isEqualTo(discount, within(0.0001));
    }

    @Test
    void testAvailableStockGetterAndSetter() {
        final int availableStock = 0;
        couponUnderTest.setAvailableStock(availableStock);
        assertThat(couponUnderTest.getAvailableStock()).isEqualTo(availableStock);
    }

    @Test
    void testValidFromGetterAndSetter() {
        final LocalDate validFrom = LocalDate.of(2020, 1, 1);
        couponUnderTest.setValidFrom(validFrom);
        assertThat(couponUnderTest.getValidFrom()).isEqualTo(validFrom);
    }

    @Test
    void testValidUntilGetterAndSetter() {
        final LocalDate validUntil = LocalDate.of(2020, 1, 1);
        couponUnderTest.setValidUntil(validUntil);
        assertThat(couponUnderTest.getValidUntil()).isEqualTo(validUntil);
    }

    @Test
    void testToString() {
        assertThat(couponUnderTest.toString()).isEqualTo("result");
    }
}
