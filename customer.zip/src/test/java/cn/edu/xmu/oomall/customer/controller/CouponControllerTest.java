package cn.edu.xmu.oomall.customer.controller;

import cn.edu.xmu.oomall.customer.controller.vo.CouponVO;
import cn.edu.xmu.oomall.customer.service.CouponService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Collections;
import java.util.List;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(CouponController.class)
class CouponControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CouponService mockCouponService;

    @Test
    void testClaimCoupon() throws Exception {
        // Setup
        // Run the test and verify the results
        mockMvc.perform(post("/coupon/claimCoupon/{couponId}", 0)
                        .param("customerId", "0")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().json("{}", true));
        verify(mockCouponService).claimCoupon(0L, 0L);
    }

    @Test
    void testGetAvailableCoupons() throws Exception {
        // Setup
        // Configure CouponService.getAvailableCoupons(...).
        final List<CouponVO> couponVOS = List.of(new CouponVO(0L, "title", 0.0, 0));
        when(mockCouponService.getAvailableCoupons()).thenReturn(couponVOS);

        // Run the test and verify the results
        mockMvc.perform(get("/coupon/availableCoupons")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().json("{}", true));
    }

    @Test
    void testGetAvailableCoupons_CouponServiceReturnsNoItems() throws Exception {
        // Setup
        when(mockCouponService.getAvailableCoupons()).thenReturn(Collections.emptyList());

        // Run the test and verify the results
        mockMvc.perform(get("/coupon/availableCoupons")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().json("[]", true));
    }

    @Test
    void testGetUserCoupons() throws Exception {
        // Setup
        // Configure CouponService.getUserCoupons(...).
        final List<CouponVO> couponVOS = List.of(new CouponVO(0L, "title", 0.0, 0));
        when(mockCouponService.getUserCoupons(0L)).thenReturn(couponVOS);

        // Run the test and verify the results
        mockMvc.perform(get("/coupon/userCoupons/{customerId}", 0)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().json("{}", true));
    }

    @Test
    void testGetUserCoupons_CouponServiceReturnsNoItems() throws Exception {
        // Setup
        when(mockCouponService.getUserCoupons(0L)).thenReturn(Collections.emptyList());

        // Run the test and verify the results
        mockMvc.perform(get("/coupon/userCoupons/{customerId}", 0)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().json("[]", true));
    }
}
