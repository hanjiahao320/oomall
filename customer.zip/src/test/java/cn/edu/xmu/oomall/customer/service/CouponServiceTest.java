package cn.edu.xmu.oomall.customer.service;

import cn.edu.xmu.oomall.customer.controller.vo.CouponVO;
import cn.edu.xmu.oomall.customer.dao.CouponHistoryRepository;
import cn.edu.xmu.oomall.customer.dao.CouponRepository;
import cn.edu.xmu.oomall.customer.dao.CustomerRepository;
import cn.edu.xmu.oomall.customer.dao.bo.Coupon;
import cn.edu.xmu.oomall.customer.dao.bo.CouponHistory;
import cn.edu.xmu.oomall.customer.dao.bo.Customer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CouponServiceTest {

    @Mock
    private CouponRepository mockCouponRepository;
    @Mock
    private CustomerRepository mockCustomerRepository;
    @Mock
    private CouponHistoryRepository mockCouponHistoryRepository;

    @InjectMocks
    private CouponService couponServiceUnderTest;

    @Test
    void testClaimCoupon() {
        // Setup
        // Configure CouponRepository.findById(...).
        final Coupon coupon1 = new Coupon();
        coupon1.setId(0L);
        coupon1.setTitle("title");
        coupon1.setDescription("description");
        coupon1.setDiscount(0.0);
        coupon1.setAvailableStock(0);
        final Optional<Coupon> coupon = Optional.of(coupon1);
        when(mockCouponRepository.findById(0L)).thenReturn(coupon);

        // Configure CustomerRepository.findById(...).
        final Optional<Customer> customer = Optional.of(new Customer(0L, "name", "email", "phone", "address"));
        when(mockCustomerRepository.findById(0L)).thenReturn(customer);

        // Run the test
        couponServiceUnderTest.claimCoupon(0L, 0L);

        // Verify the results
        verify(mockCouponRepository).save(any(Coupon.class));
        verify(mockCouponHistoryRepository).save(any(CouponHistory.class));
    }

    @Test
    void testClaimCoupon_CouponRepositoryFindByIdReturnsAbsent() {
        // Setup
        when(mockCouponRepository.findById(0L)).thenReturn(Optional.empty());

        // Run the test
        assertThatThrownBy(() -> couponServiceUnderTest.claimCoupon(0L, 0L)).isInstanceOf(RuntimeException.class);
    }

    @Test
    void testClaimCoupon_CustomerRepositoryReturnsAbsent() {
        // Setup
        // Configure CouponRepository.findById(...).
        final Coupon coupon1 = new Coupon();
        coupon1.setId(0L);
        coupon1.setTitle("title");
        coupon1.setDescription("description");
        coupon1.setDiscount(0.0);
        coupon1.setAvailableStock(0);
        final Optional<Coupon> coupon = Optional.of(coupon1);
        when(mockCouponRepository.findById(0L)).thenReturn(coupon);

        when(mockCustomerRepository.findById(0L)).thenReturn(Optional.empty());

        // Run the test
        assertThatThrownBy(() -> couponServiceUnderTest.claimCoupon(0L, 0L)).isInstanceOf(RuntimeException.class);
    }

    @Test
    void testGetAvailableCoupons() {
        // Setup
        // Configure CouponRepository.findByAvailableStockGreaterThan(...).
        final Coupon coupon = new Coupon();
        coupon.setId(0L);
        coupon.setTitle("title");
        coupon.setDescription("description");
        coupon.setDiscount(0.0);
        coupon.setAvailableStock(0);
        final List<Coupon> coupons = List.of(coupon);
        when(mockCouponRepository.findByAvailableStockGreaterThan(0)).thenReturn(coupons);

        // Run the test
        final List<CouponVO> result = couponServiceUnderTest.getAvailableCoupons();

        // Verify the results
    }

    @Test
    void testGetAvailableCoupons_CouponRepositoryReturnsNoItems() {
        // Setup
        when(mockCouponRepository.findByAvailableStockGreaterThan(0)).thenReturn(Collections.emptyList());

        // Run the test
        final List<CouponVO> result = couponServiceUnderTest.getAvailableCoupons();

        // Verify the results
        assertThat(result).isEqualTo(Collections.emptyList());
    }

    @Test
    void testGetUserCoupons() {
        // Setup
        // Configure CouponHistoryRepository.findByCustomerId(...).
        final CouponHistory couponHistory = new CouponHistory();
        final Customer customer = new Customer();
        couponHistory.setCustomer(customer);
        final Coupon coupon = new Coupon();
        coupon.setId(0L);
        coupon.setTitle("title");
        coupon.setDiscount(0.0);
        coupon.setAvailableStock(0);
        couponHistory.setCoupon(coupon);
        couponHistory.setClaimedDate(LocalDate.of(2020, 1, 1));
        final List<CouponHistory> couponHistories = List.of(couponHistory);
        when(mockCouponHistoryRepository.findByCustomerId(0L)).thenReturn(couponHistories);

        // Run the test
        final List<CouponVO> result = couponServiceUnderTest.getUserCoupons(0L);

        // Verify the results
    }

    @Test
    void testGetUserCoupons_CouponHistoryRepositoryReturnsNoItems() {
        // Setup
        when(mockCouponHistoryRepository.findByCustomerId(0L)).thenReturn(Collections.emptyList());

        // Run the test
        final List<CouponVO> result = couponServiceUnderTest.getUserCoupons(0L);

        // Verify the results
        assertThat(result).isEqualTo(Collections.emptyList());
    }
}
