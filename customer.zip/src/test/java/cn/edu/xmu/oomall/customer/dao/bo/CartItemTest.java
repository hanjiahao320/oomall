package cn.edu.xmu.oomall.customer.dao.bo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CartItemTest {

    @Mock
    private Customer mockCustomer;
    @Mock
    private Product mockProduct;

    private CartItem cartItemUnderTest;

    @BeforeEach
    void setUp() {
        cartItemUnderTest = new CartItem();
        cartItemUnderTest.setCustomer(mockCustomer);
        cartItemUnderTest.setProduct(mockProduct);
    }

    @Test
    void testIdGetterAndSetter() {
        final Long id = 0L;
        cartItemUnderTest.setId(id);
        assertThat(cartItemUnderTest.getId()).isEqualTo(id);
    }

    @Test
    void testId1GetterAndSetter() {
        final Long id = 0L;
        cartItemUnderTest.setProductId(id);
        assertThat(cartItemUnderTest.getId()).isEqualTo(id);
    }

    @Test
    void testId2GetterAndSetter() {
        final Long id = 0L;
        cartItemUnderTest.setCustomerId(id);
        assertThat(cartItemUnderTest.getId()).isEqualTo(id);
    }

    @Test
    void testGetCustomer() {
        assertThat(cartItemUnderTest.getCustomer()).isEqualTo(mockCustomer);
    }

    @Test
    void testGetProduct() {
        assertThat(cartItemUnderTest.getProduct()).isEqualTo(mockProduct);
    }

    @Test
    void testQuantityGetterAndSetter() {
        final int quantity = 0;
        cartItemUnderTest.setQuantity(quantity);
        assertThat(cartItemUnderTest.getQuantity()).isEqualTo(quantity);
    }

    @Test
    void testGetProductId() {
        // Setup
        when(mockProduct.getId()).thenReturn(0L);

        // Run the test
        final long result = cartItemUnderTest.getProductId();

        // Verify the results
        assertThat(result).isEqualTo(0L);
    }
}
