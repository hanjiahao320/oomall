package cn.edu.xmu.oomall.customer.controller.vo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.within;

class CartItemVOTest {

    private CartItemVO cartItemVOUnderTest;

    @BeforeEach
    void setUp() {
        cartItemVOUnderTest = new CartItemVO();
    }

    @Test
    void testProductIdGetterAndSetter() {
        final Long productId = 0L;
        cartItemVOUnderTest.setProductId(productId);
        assertThat(cartItemVOUnderTest.getProductId()).isEqualTo(productId);
    }

    @Test
    void testProductNameGetterAndSetter() {
        final String productName = "productName";
        cartItemVOUnderTest.setProductName(productName);
        assertThat(cartItemVOUnderTest.getProductName()).isEqualTo(productName);
    }

    @Test
    void testQuantityGetterAndSetter() {
        final int quantity = 0;
        cartItemVOUnderTest.setQuantity(quantity);
        assertThat(cartItemVOUnderTest.getQuantity()).isEqualTo(quantity);
    }

    @Test
    void testPriceGetterAndSetter() {
        final double price = 0.0;
        cartItemVOUnderTest.setPrice(price);
        assertThat(cartItemVOUnderTest.getPrice()).isEqualTo(price, within(0.0001));
    }
}
