package cn.edu.xmu.oomall.customer.controller;

import cn.edu.xmu.oomall.customer.service.CartService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(CartController.class)
class CartControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CartService mockCartService;

    @Test
    void testAddToCart() throws Exception {
        // Setup
        // Run the test and verify the results
        mockMvc.perform(post("/cart/add/{customerId}/{productId}", 0, 0)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().json("{}", true));
        verify(mockCartService).addToCart(0L, 0L);
    }

    @Test
    void testRemoveFromCart() throws Exception {
        // Setup
        // Run the test and verify the results
        mockMvc.perform(delete("/cart/remove/{customerId}/{productId}", 0, 0)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().json("{}", true));
        verify(mockCartService).removeFromCart(0L, 0L);
    }
}
