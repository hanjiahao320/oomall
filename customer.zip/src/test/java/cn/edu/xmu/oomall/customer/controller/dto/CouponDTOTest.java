package cn.edu.xmu.oomall.customer.controller.dto;

import cn.edu.xmu.oomall.customer.dao.bo.Coupon;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.within;

@ExtendWith(MockitoExtension.class)
class CouponDTOTest {

    @Mock
    private Coupon mockCoupon;

    private CouponDTO couponDTOUnderTest;

    @BeforeEach
    void setUp() {
        couponDTOUnderTest = new CouponDTO(mockCoupon);
    }

    @Test
    void testCouponIdGetterAndSetter() {
        final Long couponId = 0L;
        couponDTOUnderTest.setCouponId(couponId);
        assertThat(couponDTOUnderTest.getCouponId()).isEqualTo(couponId);
    }

    @Test
    void testTitleGetterAndSetter() {
        final String title = "title";
        couponDTOUnderTest.setTitle(title);
        assertThat(couponDTOUnderTest.getTitle()).isEqualTo(title);
    }

    @Test
    void testDiscountGetterAndSetter() {
        final double discount = 0.0;
        couponDTOUnderTest.setDiscount(discount);
        assertThat(couponDTOUnderTest.getDiscount()).isEqualTo(discount, within(0.0001));
    }

    @Test
    void testAvailableStockGetterAndSetter() {
        final int availableStock = 0;
        couponDTOUnderTest.setAvailableStock(availableStock);
        assertThat(couponDTOUnderTest.getAvailableStock()).isEqualTo(availableStock);
    }

    @Test
    void testValidUntilGetterAndSetter() {
        final LocalDate validUntil = LocalDate.of(2020, 1, 1);
        couponDTOUnderTest.setValidUntil(validUntil);
        assertThat(couponDTOUnderTest.getValidUntil()).isEqualTo(validUntil);
    }
}
