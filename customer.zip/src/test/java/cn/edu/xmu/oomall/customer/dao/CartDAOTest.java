package cn.edu.xmu.oomall.customer.dao;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CartDAOTest {

    private CartDAO cartDAOUnderTest;

    @BeforeEach
    void setUp() {
        cartDAOUnderTest = new CartDAO();
    }

    @Test
    void testAddToCart() {
        // Setup
        // Run the test
        cartDAOUnderTest.addToCart(0L, 0L);

        // Verify the results
    }

    @Test
    void testRemoveFromCart() {
        // Setup
        // Run the test
        cartDAOUnderTest.removeFromCart(0L, 0L);

        // Verify the results
    }
}
