package cn.edu.xmu.oomall.customer.controller;

import cn.edu.xmu.javaee.core.exception.BusinessException;
import cn.edu.xmu.oomall.customer.controller.dto.AddressDTO;
import cn.edu.xmu.oomall.customer.controller.dto.CartItemDTO;
import cn.edu.xmu.oomall.customer.controller.vo.AddressVO;
import cn.edu.xmu.oomall.customer.controller.vo.CartItemVO;
import cn.edu.xmu.oomall.customer.service.CustomerService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Collections;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(CustomerController.class)
class CustomerControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CustomerService mockCustomerService;

    @Test
    void testAddAddress() throws Exception {
        // Setup
        // Run the test and verify the results
        mockMvc.perform(post("/customers/addAddress")
                        .content("content").contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().json("{}", true));
        verify(mockCustomerService).addAddress(any(AddressDTO.class));
    }

    @Test
    void testAddAddress_CustomerServiceThrowsBusinessException() throws Exception {
        // Setup
        doThrow(BusinessException.class).when(mockCustomerService).addAddress(any(AddressDTO.class));

        // Run the test and verify the results
        mockMvc.perform(post("/customers/addAddress")
                        .content("content").contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().is5xxServerError())
                .andExpect(content().json("{}", true));
    }

    @Test
    void testDeleteAddress() throws Exception {
        // Setup
        // Run the test and verify the results
        mockMvc.perform(delete("/customers/deleteAddress/{addressId}", 0)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().json("{}", true));
        verify(mockCustomerService).deleteAddress(0L);
    }

    @Test
    void testDeleteAddress_CustomerServiceThrowsBusinessException() throws Exception {
        // Setup
        doThrow(BusinessException.class).when(mockCustomerService).deleteAddress(0L);

        // Run the test and verify the results
        mockMvc.perform(delete("/customers/deleteAddress/{addressId}", 0)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().is5xxServerError())
                .andExpect(content().json("{}", true));
    }

    @Test
    void testViewAddresses() throws Exception {
        // Setup
        // Configure CustomerService.viewAddresses(...).
        final AddressVO addressVO = new AddressVO();
        addressVO.setStreet("street");
        addressVO.setCity("city");
        addressVO.setZipCode("zipCode");
        final List<AddressVO> addressVOS = List.of(addressVO);
        when(mockCustomerService.viewAddresses(0L)).thenReturn(addressVOS);

        // Run the test and verify the results
        mockMvc.perform(get("/customers/viewAddresses/{customerId}", 0)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().json("{}", true));
    }

    @Test
    void testViewAddresses_CustomerServiceReturnsNoItems() throws Exception {
        // Setup
        when(mockCustomerService.viewAddresses(0L)).thenReturn(Collections.emptyList());

        // Run the test and verify the results
        mockMvc.perform(get("/customers/viewAddresses/{customerId}", 0)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().json("[]", true));
    }

    @Test
    void testClaimCoupon() throws Exception {
        // Setup
        // Run the test and verify the results
        mockMvc.perform(post("/customers/claimCoupon/{couponId}", 0)
                        .param("customerId", "0")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().json("{}", true));
        verify(mockCustomerService).claimCoupon(0L, 0L);
    }

    @Test
    void testAddToCart() throws Exception {
        // Setup
        // Run the test and verify the results
        mockMvc.perform(post("/customers/addToCart")
                        .content("content").contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().json("{}", true));
        verify(mockCustomerService).addToCart(any(CartItemDTO.class));
    }

    @Test
    void testAddToCart_CustomerServiceThrowsBusinessException() throws Exception {
        // Setup
        doThrow(BusinessException.class).when(mockCustomerService).addToCart(any(CartItemDTO.class));

        // Run the test and verify the results
        mockMvc.perform(post("/customers/addToCart")
                        .content("content").contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().is5xxServerError())
                .andExpect(content().json("{}", true));
    }

    @Test
    void testRemoveFromCart() throws Exception {
        // Setup
        // Run the test and verify the results
        mockMvc.perform(delete("/customers/removeFromCart/{cartItemId}", 0)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().json("{}", true));
        verify(mockCustomerService).removeFromCart(0L);
    }

    @Test
    void testRemoveFromCart_CustomerServiceThrowsBusinessException() throws Exception {
        // Setup
        doThrow(BusinessException.class).when(mockCustomerService).removeFromCart(0L);

        // Run the test and verify the results
        mockMvc.perform(delete("/customers/removeFromCart/{cartItemId}", 0)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().is5xxServerError())
                .andExpect(content().json("{}", true));
    }

    @Test
    void testViewCart() throws Exception {
        // Setup
        // Configure CustomerService.viewCart(...).
        final CartItemVO cartItemVO = new CartItemVO();
        cartItemVO.setProductId(0L);
        cartItemVO.setProductName("productName");
        cartItemVO.setQuantity(0);
        cartItemVO.setPrice(0.0);
        final List<CartItemVO> cartItemVOS = List.of(cartItemVO);
        when(mockCustomerService.viewCart(0L)).thenReturn(cartItemVOS);

        // Run the test and verify the results
        mockMvc.perform(get("/customers/viewCart/{customerId}", 0)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().json("{}", true));
    }

    @Test
    void testViewCart_CustomerServiceReturnsNoItems() throws Exception {
        // Setup
        when(mockCustomerService.viewCart(0L)).thenReturn(Collections.emptyList());

        // Run the test and verify the results
        mockMvc.perform(get("/customers/viewCart/{customerId}", 0)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().json("[]", true));
    }
}
