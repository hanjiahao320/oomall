package cn.edu.xmu.oomall.customer.dao;

import cn.edu.xmu.oomall.customer.dao.bo.Customer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CustomerDAOTest {

    private CustomerDAO customerDAOUnderTest;

    @BeforeEach
    void setUp() {
        customerDAOUnderTest = new CustomerDAO();
    }

    @Test
    void testAddCustomer() {
        // Setup
        final Customer customer = new Customer(0L, "name", "email", "phone", "address");

        // Run the test
        customerDAOUnderTest.addCustomer(customer);

        // Verify the results
    }

    @Test
    void testDeleteCustomer() {
        // Setup
        // Run the test
        customerDAOUnderTest.deleteCustomer(0L);

        // Verify the results
    }

    @Test
    void testGetCustomer() {
        // Setup
        // Run the test
        final Customer result = customerDAOUnderTest.getCustomer(0L);

        // Verify the results
    }
}
