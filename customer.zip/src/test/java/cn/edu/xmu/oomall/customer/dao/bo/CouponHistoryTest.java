package cn.edu.xmu.oomall.customer.dao.bo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;

import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(MockitoExtension.class)
class CouponHistoryTest {

    @Mock
    private Customer mockCustomer;
    @Mock
    private Coupon mockCoupon;

    private CouponHistory couponHistoryUnderTest;

    @BeforeEach
    void setUp() {
        couponHistoryUnderTest = new CouponHistory(0L, mockCustomer, mockCoupon, LocalDate.of(2020, 1, 1));
    }

    @Test
    void testIdGetterAndSetter() {
        final Long id = 0L;
        couponHistoryUnderTest.setId(id);
        assertThat(couponHistoryUnderTest.getId()).isEqualTo(id);
    }

    @Test
    void testCustomerGetterAndSetter() {
        final Customer customer = new Customer(0L, "name", "email", "phone", "address");
        couponHistoryUnderTest.setCustomer(customer);
        assertThat(couponHistoryUnderTest.getCustomer()).isEqualTo(customer);
    }

    @Test
    void testCouponGetterAndSetter() {
        final Coupon coupon = new Coupon();
        couponHistoryUnderTest.setCoupon(coupon);
        assertThat(couponHistoryUnderTest.getCoupon()).isEqualTo(coupon);
    }

    @Test
    void testClaimedDateGetterAndSetter() {
        final LocalDate claimedDate = LocalDate.of(2020, 1, 1);
        couponHistoryUnderTest.setClaimedDate(claimedDate);
        assertThat(couponHistoryUnderTest.getClaimedDate()).isEqualTo(claimedDate);
    }

    @Test
    void testToString() {
        assertThat(couponHistoryUnderTest.toString()).isEqualTo("result");
    }
}
