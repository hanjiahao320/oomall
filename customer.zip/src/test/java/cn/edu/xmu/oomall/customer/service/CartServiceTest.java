package cn.edu.xmu.oomall.customer.service;

import cn.edu.xmu.oomall.customer.dao.CartDAO;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class CartServiceTest {

    @Mock
    private CartDAO mockCartDAO;

    @InjectMocks
    private CartService cartServiceUnderTest;

    @Test
    void testAddToCart() {
        // Setup
        // Run the test
        cartServiceUnderTest.addToCart(0L, 0L);

        // Verify the results
        verify(mockCartDAO).addToCart(0L, 0L);
    }

    @Test
    void testRemoveFromCart() {
        // Setup
        // Run the test
        cartServiceUnderTest.removeFromCart(0L, 0L);

        // Verify the results
        verify(mockCartDAO).removeFromCart(0L, 0L);
    }
}
