package cn.edu.xmu.oomall.customer.controller.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class AddressDTOTest {

    private AddressDTO addressDTOUnderTest;

    @BeforeEach
    void setUp() {
        addressDTOUnderTest = new AddressDTO();
    }

    @Test
    void testStreetGetterAndSetter() {
        final String street = "street";
        addressDTOUnderTest.setStreet(street);
        assertThat(addressDTOUnderTest.getStreet()).isEqualTo(street);
    }

    @Test
    void testCityGetterAndSetter() {
        final String city = "city";
        addressDTOUnderTest.setCity(city);
        assertThat(addressDTOUnderTest.getCity()).isEqualTo(city);
    }

    @Test
    void testPostalCodeGetterAndSetter() {
        final String postalCode = "postalCode";
        addressDTOUnderTest.setPostalCode(postalCode);
        assertThat(addressDTOUnderTest.getPostalCode()).isEqualTo(postalCode);
    }

    @Test
    void testCountryGetterAndSetter() {
        final String country = "country";
        addressDTOUnderTest.setCountry(country);
        assertThat(addressDTOUnderTest.getCountry()).isEqualTo(country);
    }

    @Test
    void testZipCodeGetterAndSetter() {
        final String zipCode = "zipCode";
        addressDTOUnderTest.setZipCode(zipCode);
        assertThat(addressDTOUnderTest.getZipCode()).isEqualTo(zipCode);
    }

    @Test
    void testCustomerIdGetterAndSetter() {
        final Long customerId = 0L;
        addressDTOUnderTest.setCustomerId(customerId);
        assertThat(addressDTOUnderTest.getCustomerId()).isEqualTo(customerId);
    }
}
