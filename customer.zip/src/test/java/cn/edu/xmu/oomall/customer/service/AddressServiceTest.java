package cn.edu.xmu.oomall.customer.service;

import cn.edu.xmu.oomall.customer.controller.dto.AddressDTO;
import cn.edu.xmu.oomall.customer.controller.vo.AddressVO;
import cn.edu.xmu.oomall.customer.dao.AddressRepository;
import cn.edu.xmu.oomall.customer.dao.bo.Address;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AddressServiceTest {

    @Mock
    private AddressRepository mockAddressRepository;

    private AddressService addressServiceUnderTest;

    @BeforeEach
    void setUp() {
        addressServiceUnderTest = new AddressService(mockAddressRepository);
    }

    @Test
    void testAddAddress() {
        // Setup
        final AddressDTO addressDTO = new AddressDTO();
        addressDTO.setStreet("street");
        addressDTO.setCity("city");
        addressDTO.setPostalCode("postalCode");
        addressDTO.setCountry("country");
        addressDTO.setZipCode("postalCode");
        addressDTO.setCustomerId(0L);

        // Run the test
        addressServiceUnderTest.addAddress(addressDTO);

        // Verify the results
        verify(mockAddressRepository).save(any(Address.class));
    }

    @Test
    void testDeleteAddress() {
        // Setup
        // Run the test
        addressServiceUnderTest.deleteAddress(0L);

        // Verify the results
        verify(mockAddressRepository).deleteById(0L);
    }

    @Test
    void testViewAddresses() {
        // Setup
        // Configure AddressRepository.findByCustomerId(...).
        final Address address = new Address();
        address.setId(0L);
        address.setCustomerId(0L);
        address.setStreet("street");
        address.setCity("city");
        address.setPostalCode("postalCode");
        address.setCountry("country");
        final List<Address> addresses = List.of(address);
        when(mockAddressRepository.findByCustomerId(0L)).thenReturn(addresses);

        // Run the test
        final List<AddressVO> result = addressServiceUnderTest.viewAddresses(0L);

        // Verify the results
    }

    @Test
    void testViewAddresses_AddressRepositoryReturnsNoItems() {
        // Setup
        when(mockAddressRepository.findByCustomerId(0L)).thenReturn(Collections.emptyList());

        // Run the test
        final List<AddressVO> result = addressServiceUnderTest.viewAddresses(0L);

        // Verify the results
        assertThat(result).isEqualTo(Collections.emptyList());
    }

    @Test
    void testUpdateAddress() {
        // Setup
        final AddressDTO addressDTO = new AddressDTO();
        addressDTO.setStreet("street");
        addressDTO.setCity("city");
        addressDTO.setPostalCode("postalCode");
        addressDTO.setCountry("country");
        addressDTO.setZipCode("postalCode");
        addressDTO.setCustomerId(0L);

        // Configure AddressRepository.findById(...).
        final Address address1 = new Address();
        address1.setId(0L);
        address1.setCustomerId(0L);
        address1.setStreet("street");
        address1.setCity("city");
        address1.setPostalCode("postalCode");
        address1.setCountry("country");
        final Optional<Address> address = Optional.of(address1);
        when(mockAddressRepository.findById(0L)).thenReturn(address);

        // Run the test
        addressServiceUnderTest.updateAddress(0L, addressDTO);

        // Verify the results
        verify(mockAddressRepository).save(any(Address.class));
    }

    @Test
    void testUpdateAddress_AddressRepositoryFindByIdReturnsAbsent() {
        // Setup
        final AddressDTO addressDTO = new AddressDTO();
        addressDTO.setStreet("street");
        addressDTO.setCity("city");
        addressDTO.setPostalCode("postalCode");
        addressDTO.setCountry("country");
        addressDTO.setZipCode("postalCode");
        addressDTO.setCustomerId(0L);

        when(mockAddressRepository.findById(0L)).thenReturn(Optional.empty());

        // Run the test
        assertThatThrownBy(() -> addressServiceUnderTest.updateAddress(0L, addressDTO))
                .isInstanceOf(RuntimeException.class);
    }
}
