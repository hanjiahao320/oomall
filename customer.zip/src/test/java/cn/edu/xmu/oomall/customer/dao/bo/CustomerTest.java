package cn.edu.xmu.oomall.customer.dao.bo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(MockitoExtension.class)
class CustomerTest {

    @Mock
    private List<CartItem> mockCartItems;
    @Mock
    private List<CouponHistory> mockCouponHistories;

    private Customer customerUnderTest;

    @BeforeEach
    void setUp() {
        customerUnderTest = new Customer(0L, "name", "email", "phone", "address");
        customerUnderTest.setCartItems(mockCartItems);
        customerUnderTest.setCouponHistories(mockCouponHistories);
    }

    @Test
    void testIdGetterAndSetter() {
        final Long id = 0L;
        customerUnderTest.setId(id);
        assertThat(customerUnderTest.getId()).isEqualTo(id);
    }

    @Test
    void testNameGetterAndSetter() {
        final String name = "name";
        customerUnderTest.setName(name);
        assertThat(customerUnderTest.getName()).isEqualTo(name);
    }

    @Test
    void testEmailGetterAndSetter() {
        final String email = "email";
        customerUnderTest.setEmail(email);
        assertThat(customerUnderTest.getEmail()).isEqualTo(email);
    }

    @Test
    void testPhoneGetterAndSetter() {
        final String phone = "phone";
        customerUnderTest.setPhone(phone);
        assertThat(customerUnderTest.getPhone()).isEqualTo(phone);
    }

    @Test
    void testAddressGetterAndSetter() {
        final String address = "address";
        customerUnderTest.setAddress(address);
        assertThat(customerUnderTest.getAddress()).isEqualTo(address);
    }

    @Test
    void testGetCartItems() {
        assertThat(customerUnderTest.getCartItems()).isEqualTo(mockCartItems);
    }

    @Test
    void testGetCouponHistories() {
        assertThat(customerUnderTest.getCouponHistories()).isEqualTo(mockCouponHistories);
    }
}
