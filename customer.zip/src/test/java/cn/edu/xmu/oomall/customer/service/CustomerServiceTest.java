package cn.edu.xmu.oomall.customer.service;

import cn.edu.xmu.oomall.customer.controller.dto.AddressDTO;
import cn.edu.xmu.oomall.customer.controller.dto.CartItemDTO;
import cn.edu.xmu.oomall.customer.controller.vo.AddressVO;
import cn.edu.xmu.oomall.customer.controller.vo.CartItemVO;
import cn.edu.xmu.oomall.customer.dao.AddressRepository;
import cn.edu.xmu.oomall.customer.dao.CartItemRepository;
import cn.edu.xmu.oomall.customer.dao.CouponRepository;
import cn.edu.xmu.oomall.customer.dao.bo.Address;
import cn.edu.xmu.oomall.customer.dao.bo.CartItem;
import cn.edu.xmu.oomall.customer.dao.bo.Coupon;
import cn.edu.xmu.oomall.customer.dao.bo.Customer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CustomerServiceTest {

    @Mock
    private AddressRepository mockAddressRepository;
    @Mock
    private CartItemRepository mockCartItemRepository;
    @Mock
    private CouponRepository mockCouponRepository;

    @InjectMocks
    private CustomerService customerServiceUnderTest;

    @Test
    void testAddAddress() {
        // Setup
        final AddressDTO addressDTO = new AddressDTO();
        addressDTO.setStreet("street");
        addressDTO.setCity("city");
        addressDTO.setPostalCode("postalCode");
        addressDTO.setCountry("country");
        addressDTO.setCustomerId(0L);

        // Run the test
        customerServiceUnderTest.addAddress(addressDTO);

        // Verify the results
        verify(mockAddressRepository).save(any(Address.class));
    }

    @Test
    void testDeleteAddress() {
        // Setup
        // Run the test
        customerServiceUnderTest.deleteAddress(0L);

        // Verify the results
        verify(mockAddressRepository).deleteById(0L);
    }

    @Test
    void testViewAddresses() {
        // Setup
        // Run the test
        final List<AddressVO> result = customerServiceUnderTest.viewAddresses(0L);

        // Verify the results
    }

    @Test
    void testClaimCoupon() {
        customerServiceUnderTest.claimCoupon(0L, 0L);
    }

    @Test
    void testAddToCart() {
        // Setup
        final CartItemDTO cartItemDTO = new CartItemDTO(0L, 0, 0L);

        // Run the test
        customerServiceUnderTest.addToCart(cartItemDTO);

        // Verify the results
        verify(mockCartItemRepository).save(any(CartItem.class));
    }

    @Test
    void testRemoveFromCart() {
        // Setup
        // Run the test
        customerServiceUnderTest.removeFromCart(0L);

        // Verify the results
        verify(mockCartItemRepository).deleteById(0L);
    }

    @Test
    void testViewCart() {
        // Setup
        // Configure CartItemRepository.findCartItemsByCustomerId(...).
        final CartItem cartItem = new CartItem();
        cartItem.setCustomerId(0L);
        final Customer customer = new Customer();
        customer.setId(0L);
        customer.setName("name");
        cartItem.setCustomer(customer);
        cartItem.setQuantity(0);
        final List<CartItem> cartItems = List.of(cartItem);
        when(mockCartItemRepository.findCartItemsByCustomerId(0L)).thenReturn(cartItems);

        // Run the test
        final List<CartItemVO> result = customerServiceUnderTest.viewCart(0L);

        // Verify the results
    }

    @Test
    void testViewCart_CartItemRepositoryReturnsNoItems() {
        // Setup
        when(mockCartItemRepository.findCartItemsByCustomerId(0L)).thenReturn(Collections.emptyList());

        // Run the test
        final List<CartItemVO> result = customerServiceUnderTest.viewCart(0L);

        // Verify the results
        assertThat(result).isEqualTo(Collections.emptyList());
    }

    @Test
    void testGetAvailableCoupons() {
        // Setup
        // Configure CouponRepository.findAllByIsValidTrue(...).
        final Coupon coupon = new Coupon();
        coupon.setId(0L);
        coupon.setTitle("title");
        coupon.setDescription("description");
        coupon.setDiscount(0.0);
        coupon.setAvailableStock(0);
        final List<Coupon> coupons = List.of(coupon);
        when(mockCouponRepository.findAllByIsValidTrue()).thenReturn(coupons);

        // Run the test
        final List<Coupon> result = customerServiceUnderTest.getAvailableCoupons();

        // Verify the results
    }

    @Test
    void testGetAvailableCoupons_CouponRepositoryReturnsNoItems() {
        // Setup
        when(mockCouponRepository.findAllByIsValidTrue()).thenReturn(Collections.emptyList());

        // Run the test
        final List<Coupon> result = customerServiceUnderTest.getAvailableCoupons();

        // Verify the results
        assertThat(result).isEqualTo(Collections.emptyList());
    }

    @Test
    void testGetUserCoupons() {
        // Setup
        // Configure CouponRepository.findByCustomerIdAndIsValidTrue(...).
        final Coupon coupon = new Coupon();
        coupon.setId(0L);
        coupon.setTitle("title");
        coupon.setDescription("description");
        coupon.setDiscount(0.0);
        coupon.setAvailableStock(0);
        final List<Coupon> coupons = List.of(coupon);
        when(mockCouponRepository.findByCustomerIdAndIsValidTrue(0L)).thenReturn(coupons);

        // Run the test
        final List<Coupon> result = customerServiceUnderTest.getUserCoupons(0L);

        // Verify the results
    }

    @Test
    void testGetUserCoupons_CouponRepositoryReturnsNoItems() {
        // Setup
        when(mockCouponRepository.findByCustomerIdAndIsValidTrue(0L)).thenReturn(Collections.emptyList());

        // Run the test
        final List<Coupon> result = customerServiceUnderTest.getUserCoupons(0L);

        // Verify the results
        assertThat(result).isEqualTo(Collections.emptyList());
    }
}
