package cn.edu.xmu.oomall.customer.dao.bo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class AddressTest {

    private Address addressUnderTest;

    @BeforeEach
    void setUp() {
        addressUnderTest = new Address();
    }

    @Test
    void testIdGetterAndSetter() {
        final Long id = 0L;
        addressUnderTest.setId(id);
        assertThat(addressUnderTest.getId()).isEqualTo(id);
    }

    @Test
    void testCustomerIdGetterAndSetter() {
        final Long customerId = 0L;
        addressUnderTest.setCustomerId(customerId);
        assertThat(addressUnderTest.getCustomerId()).isEqualTo(customerId);
    }

    @Test
    void testStreetGetterAndSetter() {
        final String street = "street";
        addressUnderTest.setStreet(street);
        assertThat(addressUnderTest.getStreet()).isEqualTo(street);
    }

    @Test
    void testCityGetterAndSetter() {
        final String city = "city";
        addressUnderTest.setCity(city);
        assertThat(addressUnderTest.getCity()).isEqualTo(city);
    }
}
