package cn.edu.xmu.oomall.customer.controller.vo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class AddressVOTest {

    private AddressVO addressVOUnderTest;

    @BeforeEach
    void setUp() {
        addressVOUnderTest = new AddressVO(0L, "street", "city", "postalCode", "country");
    }

    @Test
    void testIdGetterAndSetter() {
        final Long id = 0L;
        addressVOUnderTest.setId(id);
        assertThat(addressVOUnderTest.getId()).isEqualTo(id);
    }

    @Test
    void testStreetGetterAndSetter() {
        final String street = "street";
        addressVOUnderTest.setStreet(street);
        assertThat(addressVOUnderTest.getStreet()).isEqualTo(street);
    }

    @Test
    void testCityGetterAndSetter() {
        final String city = "city";
        addressVOUnderTest.setCity(city);
        assertThat(addressVOUnderTest.getCity()).isEqualTo(city);
    }

    @Test
    void testPostalCodeGetterAndSetter() {
        final String postalCode = "postalCode";
        addressVOUnderTest.setPostalCode(postalCode);
        assertThat(addressVOUnderTest.getPostalCode()).isEqualTo(postalCode);
    }

    @Test
    void testCountryGetterAndSetter() {
        final String country = "country";
        addressVOUnderTest.setCountry(country);
        assertThat(addressVOUnderTest.getCountry()).isEqualTo(country);
    }

    @Test
    void testToString() {
        assertThat(addressVOUnderTest.toString()).isEqualTo("result");
    }
}
