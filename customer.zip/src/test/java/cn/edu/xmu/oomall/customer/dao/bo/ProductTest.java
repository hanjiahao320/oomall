package cn.edu.xmu.oomall.customer.dao.bo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.within;

class ProductTest {

    private Product productUnderTest;

    @BeforeEach
    void setUp() {
        productUnderTest = new Product(0L, "name", 0.0, "description", "imageUrl");
    }

    @Test
    void testIdGetterAndSetter() {
        final Long id = 0L;
        productUnderTest.setId(id);
        assertThat(productUnderTest.getId()).isEqualTo(id);
    }

    @Test
    void testNameGetterAndSetter() {
        final String name = "name";
        productUnderTest.setName(name);
        assertThat(productUnderTest.getName()).isEqualTo(name);
    }

    @Test
    void testPriceGetterAndSetter() {
        final double price = 0.0;
        productUnderTest.setPrice(price);
        assertThat(productUnderTest.getPrice()).isEqualTo(price, within(0.0001));
    }

    @Test
    void testDescriptionGetterAndSetter() {
        final String description = "description";
        productUnderTest.setDescription(description);
        assertThat(productUnderTest.getDescription()).isEqualTo(description);
    }

    @Test
    void testImageUrlGetterAndSetter() {
        final String imageUrl = "imageUrl";
        productUnderTest.setImageUrl(imageUrl);
        assertThat(productUnderTest.getImageUrl()).isEqualTo(imageUrl);
    }
}
