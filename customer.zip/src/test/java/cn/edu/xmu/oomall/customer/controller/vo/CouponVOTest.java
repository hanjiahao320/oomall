package cn.edu.xmu.oomall.customer.controller.vo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.within;

class CouponVOTest {

    private CouponVO couponVOUnderTest;

    @BeforeEach
    void setUp() {
        couponVOUnderTest = new CouponVO(0L, "title", 0.0, 0);
    }

    @Test
    void testIdGetterAndSetter() {
        final Long id = 0L;
        couponVOUnderTest.setId(id);
        assertThat(couponVOUnderTest.getId()).isEqualTo(id);
    }

    @Test
    void testTitleGetterAndSetter() {
        final String title = "title";
        couponVOUnderTest.setTitle(title);
        assertThat(couponVOUnderTest.getTitle()).isEqualTo(title);
    }

    @Test
    void testDiscountGetterAndSetter() {
        final double discount = 0.0;
        couponVOUnderTest.setDiscount(discount);
        assertThat(couponVOUnderTest.getDiscount()).isEqualTo(discount, within(0.0001));
    }

    @Test
    void testAvailableStockGetterAndSetter() {
        final int availableStock = 0;
        couponVOUnderTest.setAvailableStock(availableStock);
        assertThat(couponVOUnderTest.getAvailableStock()).isEqualTo(availableStock);
    }

    @Test
    void testToString() {
        assertThat(couponVOUnderTest.toString()).isEqualTo("result");
    }
}
