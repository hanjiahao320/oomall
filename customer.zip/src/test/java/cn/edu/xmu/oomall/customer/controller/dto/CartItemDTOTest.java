package cn.edu.xmu.oomall.customer.controller.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class CartItemDTOTest {

    private CartItemDTO cartItemDTOUnderTest;

    @BeforeEach
    void setUp() {
        cartItemDTOUnderTest = new CartItemDTO(0L, 0, 0L);
    }

    @Test
    void testProductIdGetterAndSetter() {
        final Long productId = 0L;
        cartItemDTOUnderTest.setProductId(productId);
        assertThat(cartItemDTOUnderTest.getProductId()).isEqualTo(productId);
    }

    @Test
    void testQuantityGetterAndSetter() {
        final int quantity = 0;
        cartItemDTOUnderTest.setQuantity(quantity);
        assertThat(cartItemDTOUnderTest.getQuantity()).isEqualTo(quantity);
    }

    @Test
    void testCustomerIdGetterAndSetter() {
        final Long customerId = 0L;
        cartItemDTOUnderTest.setCustomerId(customerId);
        assertThat(cartItemDTOUnderTest.getCustomerId()).isEqualTo(customerId);
    }
}
